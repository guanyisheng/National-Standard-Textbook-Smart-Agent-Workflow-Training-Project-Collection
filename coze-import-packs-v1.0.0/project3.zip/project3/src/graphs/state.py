# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
from typing import Optional, List, Dict
from pydantic import BaseModel, Field


class GlobalState(BaseModel):
    """全局状态定义"""
    user_query: str = Field(default="", description="用户原始学习问题")
    user_info: dict = Field(default={}, description="提取的用户结构化信息")
    need_type: str = Field(default="", description="分类后的需求类型")
    specialist_advice: str = Field(default="", description="专项分析建议")
    learning_plan: str = Field(default="", description="最终整合的学习规划方案文本")
    pdf_url: str = Field(default="", description="PDF文档下载地址")
    docx_url: str = Field(default="", description="DOCX文档下载地址")


class GraphInput(BaseModel):
    """工作流的输入"""
    user_query: str = Field(..., description="用户的学习问题或情况描述，包括当前阶段、专业方向、学习目标、可用时间、当前困难等信息")


class GraphOutput(BaseModel):
    """工作流的输出"""
    learning_plan: str = Field(..., description="生成的个性化学习规划方案文本")
    pdf_url: str = Field(default="", description="PDF文档下载地址")
    docx_url: str = Field(default="", description="DOCX文档下载地址")


# ============ 信息提取节点 ============
class InfoExtractionInput(BaseModel):
    """信息提取节点的输入"""
    user_query: str = Field(..., description="用户原始学习问题描述")


class InfoExtractionOutput(BaseModel):
    """信息提取节点的输出"""
    user_info: dict = Field(..., description="提取的用户结构化信息，包含grade/major/current_level/goals/available_time/difficulties")


# ============ 需求分类节点 ============
class NeedClassificationInput(BaseModel):
    """需求分类节点的输入"""
    user_query: str = Field(..., description="用户原始学习问题")
    user_info: dict = Field(..., description="提取的用户信息")


class NeedClassificationOutput(BaseModel):
    """需求分类节点的输出"""
    need_type: str = Field(..., description="需求类型：制定学习计划/提高学习效率/解决学习困难/规划考试准备/学习方向选择")


# ============ 路由决策（条件分支用） ============
class RouteDecision(BaseModel):
    """路由决策的输入"""
    need_type: str = Field(..., description="需求类型")


# ============ 专项分析节点（5个专项共用相同结构） ============
class SpecialistInput(BaseModel):
    """专项分析节点的输入"""
    user_query: str = Field(..., description="用户原始学习问题")
    user_info: dict = Field(..., description="提取的用户结构化信息")


class SpecialistOutput(BaseModel):
    """专项分析节点的输出"""
    specialist_advice: str = Field(..., description="专项分析建议内容")


# ============ 方案整合节点 ============
class PlanAssemblyInput(BaseModel):
    """方案整合节点的输入"""
    user_query: str = Field(..., description="用户原始学习问题")
    user_info: dict = Field(..., description="提取的用户结构化信息")
    need_type: str = Field(..., description="需求类型")
    specialist_advice: str = Field(..., description="专项分析建议")


class PlanAssemblyOutput(BaseModel):
    """方案整合节点的输出"""
    learning_plan: str = Field(..., description="最终整合的学习规划方案文本")


# ============ 文档生成节点 ============
class DocumentGeneratorInput(BaseModel):
    """文档生成节点的输入"""
    learning_plan: str = Field(..., description="整合后的学习规划方案文本")
    user_info: dict = Field(..., description="用户信息，用于生成文件名")
    need_type: str = Field(..., description="需求类型，用于文档标题")


class DocumentGeneratorOutput(BaseModel):
    """文档生成节点的输出"""
    pdf_url: str = Field(default="", description="PDF文档下载地址")
    docx_url: str = Field(default="", description="DOCX文档下载地址")
