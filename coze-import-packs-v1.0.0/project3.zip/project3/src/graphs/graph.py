# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
from langgraph.graph import StateGraph, END
from graphs.state import GlobalState, GraphInput, GraphOutput, RouteDecision
from graphs.nodes.info_extraction_node import info_extraction_node
from graphs.nodes.need_classification_node import need_classification_node
from graphs.nodes.study_plan_node import study_plan_node
from graphs.nodes.efficiency_coach_node import efficiency_coach_node
from graphs.nodes.difficulty_solver_node import difficulty_solver_node
from graphs.nodes.exam_planner_node import exam_planner_node
from graphs.nodes.direction_advisor_node import direction_advisor_node
from graphs.nodes.plan_assembly_node import plan_assembly_node
from graphs.nodes.document_generator_node import document_generator_node


def route_to_specialist(state: RouteDecision) -> str:
    """
    title: 需求路由
    desc: 根据需求分类结果，将流程路由到对应的专项分析节点。返回path_map中的键（中文需求类型名），由path_map映射到节点名
    """
    valid_types = ["制定学习计划", "提高学习效率", "解决学习困难", "规划考试准备", "学习方向选择"]
    if state.need_type in valid_types:
        return state.need_type
    return "制定学习计划"


# 创建状态图，指定全局状态、输入和输出结构
builder = StateGraph(GlobalState, input_schema=GraphInput, output_schema=GraphOutput)

# ============ 添加节点 ============

# 第一步：信息提取（Agent节点 - 大模型）
builder.add_node(
    "info_extraction",
    info_extraction_node,
    metadata={
        "type": "agent",
        "llm_cfg": "config/info_extraction_llm_cfg.json"
    }
)

# 第二步：需求分类（Task节点 - 关键词规则匹配，无需大模型）
builder.add_node("need_classification", need_classification_node)

# 第三步（分支1）：学习计划制定（Agent节点 - 大模型）
builder.add_node(
    "study_plan",
    study_plan_node,
    metadata={
        "type": "agent",
        "llm_cfg": "config/study_plan_llm_cfg.json"
    }
)

# 第三步（分支2）：学习效率提升（Agent节点 - 大模型）
builder.add_node(
    "efficiency_coach",
    efficiency_coach_node,
    metadata={
        "type": "agent",
        "llm_cfg": "config/efficiency_coach_llm_cfg.json"
    }
)

# 第三步（分支3）：学习困难诊断（Agent节点 - 大模型）
builder.add_node(
    "difficulty_solver",
    difficulty_solver_node,
    metadata={
        "type": "agent",
        "llm_cfg": "config/difficulty_solver_llm_cfg.json"
    }
)

# 第三步（分支4）：考试备考规划（Agent节点 - 大模型）
builder.add_node(
    "exam_planner",
    exam_planner_node,
    metadata={
        "type": "agent",
        "llm_cfg": "config/exam_planner_llm_cfg.json"
    }
)

# 第三步（分支5）：学习方向建议（Agent节点 - 大模型）
builder.add_node(
    "direction_advisor",
    direction_advisor_node,
    metadata={
        "type": "agent",
        "llm_cfg": "config/direction_advisor_llm_cfg.json"
    }
)

# 第四步：方案整合（Task节点 - Jinja2模板渲染，无需大模型）
builder.add_node("plan_assembly", plan_assembly_node)

# 第五步：文档生成（Task节点 - 生成Markdown文件并上传对象存储，无需大模型）
builder.add_node("document_generator", document_generator_node)

# ============ 编排边 ============

# 设置入口点
builder.set_entry_point("info_extraction")

# 信息提取 → 需求分类
builder.add_edge("info_extraction", "need_classification")

# 需求分类 → 条件分支（5选1）
builder.add_conditional_edges(
    source="need_classification",
    path=route_to_specialist,
    path_map={
        "制定学习计划": "study_plan",
        "提高学习效率": "efficiency_coach",
        "解决学习困难": "difficulty_solver",
        "规划考试准备": "exam_planner",
        "学习方向选择": "direction_advisor"
    }
)

# 所有专项节点 → 方案整合
builder.add_edge("study_plan", "plan_assembly")
builder.add_edge("efficiency_coach", "plan_assembly")
builder.add_edge("difficulty_solver", "plan_assembly")
builder.add_edge("exam_planner", "plan_assembly")
builder.add_edge("direction_advisor", "plan_assembly")

# 方案整合 → 文档生成
builder.add_edge("plan_assembly", "document_generator")

# 文档生成 → 结束
builder.add_edge("document_generator", END)

# 编译图
main_graph = builder.compile()
