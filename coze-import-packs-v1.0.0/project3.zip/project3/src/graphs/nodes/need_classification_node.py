# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
import re
from typing import Dict, List
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import NeedClassificationInput, NeedClassificationOutput


# 需求类型关键词映射表（按优先级排序）
NEED_TYPE_KEYWORDS: Dict[str, List[str]] = {
    "规划考试准备": [
        "考试", "考研", "高考", "雅思", "托福", "四六级", "公务员", "备考",
        "复习", "冲刺", "模考", "真题", "笔试", "面试", "分数", "408",
        "期末", "补考", "复试", "初试", "资格证", "CPA", "CFA"
    ],
    "解决学习困难": [
        "困难", "不懂", "学不会", "跟不上", "吃力", "难", "跟不上",
        "薄弱", "基础差", "听不懂", "做不出", "理解不了", "卡住",
        "瓶颈", "挫败", "焦虑", "跟不上进度"
    ],
    "提高学习效率": [
        "效率", "方法", "习惯", "拖延", "注意力", "分心", "时间管理",
        "学不进去", "记不住", "忘得快", "集中", "自律", "高效",
        "提速", "优化", "番茄", "专注"
    ],
    "学习方向选择": [
        "方向", "选择", "转专业", "就业", "迷茫", "不知道该学",
        "前景", "出路", "跨考", "转型", "哪个", "还是", "纠结",
        "适合", "兴趣", "职业规划", "发展"
    ],
    "制定学习计划": [
        "计划", "安排", "规划", "时间表", "学期", "每天", "每周",
        "怎么学", "如何开始", "步骤", "路线", "路径", "目标"
    ]
}

VALID_NEED_TYPES = [
    "制定学习计划", "提高学习效率", "解决学习困难",
    "规划考试准备", "学习方向选择"
]


def _classify_by_keywords(text: str) -> str:
    """基于关键词匹配进行需求分类，返回匹配得分最高的需求类型"""
    text_lower = text.lower()
    scores: Dict[str, int] = {}

    for need_type, keywords in NEED_TYPE_KEYWORDS.items():
        score = 0
        for kw in keywords:
            if kw in text_lower:
                score += 1
        scores[need_type] = score

    # 取得分最高的类型
    best_type = max(scores, key=lambda k: scores[k])
    if scores[best_type] > 0:
        return best_type

    # 无匹配时默认返回"制定学习计划"
    return "制定学习计划"


def need_classification_node(state: NeedClassificationInput, config: RunnableConfig, runtime: Runtime[Context]) -> NeedClassificationOutput:
    """
    title: 需求分类
    desc: 通过关键词规则匹配，将用户需求分类为五种类型之一：制定学习计划、提高学习效率、解决学习困难、规划考试准备、学习方向选择。纯规则引擎，无需大模型。
    """
    # 组合用户原始问题和用户信息中的文本用于关键词匹配
    match_text = state.user_query

    # 从 user_info 中提取额外文本辅助分类
    if isinstance(state.user_info, dict):
        info_texts = []
        for v in state.user_info.values():
            if isinstance(v, str):
                info_texts.append(v)
            elif isinstance(v, list):
                info_texts.extend([str(item) for item in v if isinstance(item, str)])
        if info_texts:
            match_text = match_text + " " + " ".join(info_texts)

    need_type = _classify_by_keywords(match_text)

    # 安全校验
    if need_type not in VALID_NEED_TYPES:
        need_type = "制定学习计划"

    return NeedClassificationOutput(need_type=need_type)
