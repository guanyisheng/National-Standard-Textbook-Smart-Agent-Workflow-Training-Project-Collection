# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
import os
import json
from typing import Any, Dict
from jinja2 import Template
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from graphs.state import InfoExtractionInput, InfoExtractionOutput


def _extract_text_from_response(content: Any) -> str:
    """从LLM响应中安全提取文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            text_parts: list[str] = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            return " ".join(text_parts)
    return str(content)


def info_extraction_node(state: InfoExtractionInput, config: RunnableConfig, runtime: Runtime[Context]) -> InfoExtractionOutput:
    """
    title: 用户信息提取
    desc: 从用户的自然语言描述中提取结构化的学习信息，包括学生阶段、专业方向、当前水平、学习目标、可用时间、当前困难等
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 读取大模型配置文件
    cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH", ""), config["metadata"]["llm_cfg"])
    with open(cfg_file, "r", encoding="utf-8") as fd:
        llm_cfg = json.load(fd)

    llm_config: Dict[str, Any] = llm_cfg.get("config", {})
    sp: str = llm_cfg.get("sp", "")
    up: str = llm_cfg.get("up", "")

    # 渲染用户提示词模板
    up_tpl = Template(up)
    rendered_up = up_tpl.render(user_query=state.user_query)

    # 构建消息并调用大模型
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=rendered_up)
    ]

    client = LLMClient(ctx=ctx)
    response = client.invoke(
        messages=messages,
        model=llm_config.get("model", "doubao-seed-2-0-lite-260215"),
        temperature=llm_config.get("temperature", 0.1),
        top_p=llm_config.get("top_p", 0.9),
        max_completion_tokens=llm_config.get("max_completion_tokens", 2048),
        thinking=llm_config.get("thinking", "disabled")
    )

    # 解析LLM返回的JSON
    raw_text = _extract_text_from_response(response.content)
    try:
        # 尝试清理可能的markdown代码块标记
        cleaned_text = raw_text.strip()
        if cleaned_text.startswith("```"):
            lines = cleaned_text.split("\n")
            lines = [l for l in lines if not l.strip().startswith("```")]
            cleaned_text = "\n".join(lines)
        user_info: dict = json.loads(cleaned_text)
    except (json.JSONDecodeError, Exception):
        # 如果解析失败，构造默认结构
        user_info = {
            "grade": "未提供",
            "major": "未提供",
            "current_level": state.user_query[:100],
            "goals": "未提供",
            "available_time": "未提供",
            "difficulties": []
        }

    return InfoExtractionOutput(user_info=user_info)
