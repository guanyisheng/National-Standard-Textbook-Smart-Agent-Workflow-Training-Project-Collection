# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
import os
import json
from typing import Any, Dict
from jinja2 import Template
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from graphs.state import SpecialistInput, SpecialistOutput


def _extract_text_from_response(content: Any) -> str:
    """从LLM响应中安全提取文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            text_parts: list[str] = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            return " ".join(text_parts)
    return str(content)


def exam_planner_node(state: SpecialistInput, config: RunnableConfig, runtime: Runtime[Context]) -> SpecialistOutput:
    """
    title: 考试备考规划
    desc: 根据目标考试的特点和用户当前水平，制定分阶段备考计划，包含基础复习、强化训练和冲刺模拟
    integrations: 大语言模型
    """
    ctx = runtime.context

    cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH", ""), config["metadata"]["llm_cfg"])
    with open(cfg_file, "r", encoding="utf-8") as fd:
        llm_cfg = json.load(fd)

    llm_config: Dict[str, Any] = llm_cfg.get("config", {})
    sp: str = llm_cfg.get("sp", "")
    up: str = llm_cfg.get("up", "")

    user_info_str = json.dumps(state.user_info, ensure_ascii=False, indent=2)
    up_tpl = Template(up)
    rendered_up = up_tpl.render(user_info=user_info_str, user_query=state.user_query)

    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=rendered_up)
    ]

    client = LLMClient(ctx=ctx)
    response = client.invoke(
        messages=messages,
        model=llm_config.get("model", "doubao-seed-2-0-lite-260215"),
        temperature=llm_config.get("temperature", 0.7),
        top_p=llm_config.get("top_p", 0.9),
        max_completion_tokens=llm_config.get("max_completion_tokens", 4096),
        thinking=llm_config.get("thinking", "disabled")
    )

    specialist_advice = _extract_text_from_response(response.content)
    return SpecialistOutput(specialist_advice=specialist_advice)
