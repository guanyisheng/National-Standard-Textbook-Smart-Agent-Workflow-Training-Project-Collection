# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
import os
import re
import time
from typing import Optional
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import DocumentGenerationClient, PDFConfig, DOCXConfig
from graphs.state import DocumentGeneratorInput, DocumentGeneratorOutput


def _sanitize_title(name: str) -> str:
    """清理文件名，仅保留英文、数字、下划线、短横"""
    cleaned = re.sub(r'[^\w\-.]', '_', name)
    cleaned = re.sub(r'_+', '_', cleaned)
    if len(cleaned) > 50:
        cleaned = cleaned[:50]
    return cleaned.strip('_') or 'learning_plan'


def document_generator_node(state: DocumentGeneratorInput, config: RunnableConfig, runtime: Runtime[Context]) -> DocumentGeneratorOutput:
    """
    title: 文档导出
    desc: 将学习规划方案导出为 PDF 和 DOCX 两种格式的专业文档，自动上传到对象存储并返回下载地址。纯文件操作，无需大模型。
    integrations: 文档生成, 对象存储
    """
    ctx = runtime.context

    # 从用户信息中提取标识用于文件名
    grade = ""
    if isinstance(state.user_info, dict):
        grade = state.user_info.get("grade", "")
    if not isinstance(grade, str):
        grade = ""

    timestamp = int(time.time())
    safe_grade = _sanitize_title(grade)
    base_title = f"learning_plan_{safe_grade}_{timestamp}"

    # 确保 Markdown 内容中不含 emoji（避免 PDF 渲染问题）
    content = state.learning_plan
    # 移除 emoji 字符
    emoji_pattern = re.compile(
        "["
        "\U0001F600-\U0001F64F"
        "\U0001F300-\U0001F5FF"
        "\U0001F680-\U0001F6FF"
        "\U0001F1E0-\U0001F1FF"
        "\U00002702-\U000027B0"
        "\U000024C2-\U0001F251"
        "]+",
        flags=re.UNICODE,
    )
    content = emoji_pattern.sub('', content)

    # 初始化文档生成客户端
    pdf_client = DocumentGenerationClient(
        pdf_config=PDFConfig(page_size="A4")
    )
    docx_client = DocumentGenerationClient(
        docx_config=DOCXConfig(font_name="Noto Sans CJK SC", font_size=11)
    )

    # 生成 PDF 文档
    pdf_url = ""
    try:
        pdf_url = pdf_client.create_pdf_from_markdown(content, base_title)
    except Exception as e:
        pdf_url = ""

    # 生成 DOCX 文档
    docx_url = ""
    try:
        docx_url = docx_client.create_docx_from_markdown(content, base_title)
    except Exception as e:
        docx_url = ""

    return DocumentGeneratorOutput(pdf_url=pdf_url, docx_url=docx_url)
