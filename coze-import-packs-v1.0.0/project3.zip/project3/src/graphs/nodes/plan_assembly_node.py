# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
import json
import datetime
from typing import Any, Dict
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import PlanAssemblyInput, PlanAssemblyOutput


# 学习规划文档的 Jinja2 模板
PLAN_TEMPLATE = """# 📚 个人学习规划方案

> 生成时间：{{ generated_time }}
> 需求类型：{{ need_type }}

---

## 一、你的情况分析

{% if user_info.grade and user_info.grade != '未提供' %}- **当前阶段**：{{ user_info.grade }}
{% endif %}{% if user_info.major and user_info.major != '未提供' %}- **专业方向**：{{ user_info.major }}
{% endif %}{% if user_info.current_level %}- **当前水平**：{{ user_info.current_level }}
{% endif %}{% if user_info.goals and user_info.goals != '未提供' %}- **学习目标**：{{ user_info.goals }}
{% endif %}{% if user_info.available_time and user_info.available_time != '未提供' %}- **可用时间**：{{ user_info.available_time }}
{% endif %}{% if user_info.difficulties %}- **当前困难**：{{ user_info.difficulties | join('、') }}
{% endif %}

---

## 二、专项建议

{{ specialist_advice }}

---

## 三、行动清单

根据以上建议，以下是你可以立即开始的行动步骤：

1. ✅ **今天**：回顾本方案，明确自己的目标和当前差距
2. ✅ **本周**：按照方案中的阶段规划，开始第一个阶段的学习任务
3. ✅ **持续**：每周回顾一次学习进度，根据实际情况微调计划

---

## 四、温馨提示

- 学习是一个循序渐进的过程，不要因为短期看不到效果而气馁
- 适当休息和运动同样重要，保持好的身体状态才能高效学习
- 遇到困难时及时调整方法，不要死磕一个方向
- 定期复盘，记录自己的进步和成长

---

*本方案由个人学习规划顾问工作流生成，祝你学习顺利！*
"""


def _get_user_info_field(user_info: Any, key: str, default: str = "") -> str:
    """安全地从 user_info dict 中获取字段值"""
    if not isinstance(user_info, dict):
        return default
    val = user_info.get(key, default)
    if isinstance(val, str):
        return val
    if isinstance(val, list):
        return "、".join(str(item) for item in val)
    return str(val) if val else default


def plan_assembly_node(state: PlanAssemblyInput, config: RunnableConfig, runtime: Runtime[Context]) -> PlanAssemblyOutput:
    """
    title: 方案整合
    desc: 使用 Jinja2 模板将专项建议与用户信息整合为结构化的学习规划文档，纯模板渲染，无需大模型。
    """
    # 构造安全的用户信息字典
    safe_user_info = {
        "grade": _get_user_info_field(state.user_info, "grade", "未提供"),
        "major": _get_user_info_field(state.user_info, "major", "未提供"),
        "current_level": _get_user_info_field(state.user_info, "current_level", ""),
        "goals": _get_user_info_field(state.user_info, "goals", "未提供"),
        "available_time": _get_user_info_field(state.user_info, "available_time", "未提供"),
        "difficulties": state.user_info.get("difficulties", []) if isinstance(state.user_info, dict) else []
    }

    # 确保 difficulties 是列表
    if not isinstance(safe_user_info["difficulties"], list):
        safe_user_info["difficulties"] = []

    # 获取当前时间
    now = datetime.datetime.now()
    generated_time = now.strftime("%Y年%m月%d日 %H:%M")

    # 使用 Jinja2 模板渲染
    tpl = Template(PLAN_TEMPLATE)
    learning_plan = tpl.render(
        generated_time=generated_time,
        need_type=state.need_type,
        user_info=safe_user_info,
        specialist_advice=state.specialist_advice
    )

    return PlanAssemblyOutput(learning_plan=learning_plan)
