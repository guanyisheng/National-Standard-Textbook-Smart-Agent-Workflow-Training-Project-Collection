## 项目概述
- **名称**: 个人学习规划顾问
- **功能**: 根据学生情况智能分析需求，提供个性化学习规划方案，并导出为 PDF/DOCX 文档

### 节点清单
| 节点名 | 文件位置 | 类型 | 功能描述 | 分支逻辑 | 配置文件 |
|-------|---------|------|---------|---------|---------|
| info_extraction | `nodes/info_extraction_node.py` | agent | 提取用户结构化信息（年级/专业/水平/目标/时间/困难） | - | `config/info_extraction_llm_cfg.json` |
| need_classification | `nodes/need_classification_node.py` | task | 基于关键词规则匹配分类需求类型（无需LLM） | 5种分支 | - |
| study_plan | `nodes/study_plan_node.py` | agent | 制定系统学习计划 | - | `config/study_plan_llm_cfg.json` |
| efficiency_coach | `nodes/efficiency_coach_node.py` | agent | 诊断效率瓶颈，推荐学习方法 | - | `config/efficiency_coach_llm_cfg.json` |
| difficulty_solver | `nodes/difficulty_solver_node.py` | agent | 诊断学习困难根源，提供解决方案 | - | `config/difficulty_solver_llm_cfg.json` |
| exam_planner | `nodes/exam_planner_node.py` | agent | 制定分阶段备考计划 | - | `config/exam_planner_llm_cfg.json` |
| direction_advisor | `nodes/direction_advisor_node.py` | agent | 分析学习方向前景和适合度 | - | `config/direction_advisor_llm_cfg.json` |
| plan_assembly | `nodes/plan_assembly_node.py` | task | 使用Jinja2模板整合方案为结构化Markdown（无需LLM） | - | - |
| document_generator | `nodes/document_generator_node.py` | task | 将方案导出为PDF+DOCX文档，上传对象存储（无需LLM） | - | - |

**类型说明**: task(task节点) / agent(大模型) / condition(条件分支) / looparray(列表循环) / loopcond(条件循环)

### 条件分支路由
需求分类节点根据关键词匹配输出5种需求类型，路由到对应专项分析节点：
- "制定学习计划" → study_plan
- "提高学习效率" → efficiency_coach
- "解决学习困难" → difficulty_solver
- "规划考试准备" → exam_planner
- "学习方向选择" → direction_advisor

## 技能使用
- 节点 `info_extraction` 使用技能：大语言模型
- 节点 `study_plan` / `efficiency_coach` / `difficulty_solver` / `exam_planner` / `direction_advisor` 使用技能：大语言模型
- 节点 `document_generator` 使用技能：文档生成、对象存储
