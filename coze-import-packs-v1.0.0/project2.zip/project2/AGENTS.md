## 项目概述
- **名称**: 智能学习助手
- **功能**: 单智能体学习辅助系统，提供学生画像分析、上下文记忆管理、智能任务规划（知识答疑/学习计划/错题分析/学习评价）、资源推荐、方案生成和学习记录等全流程学习辅助服务

### 节点清单
| 节点名 | 文件位置 | 类型 | 功能描述 | 分支逻辑 | 配置文件 |
|-------|---------|------|---------|---------|---------|
| student_profile | `nodes/student_profile_node.py` | agent | 分析学生画像并判断任务类型 | - | `config/student_profile_llm_cfg.json` |
| context_memory | `nodes/context_memory_node.py` | task | 整合画像、历史数据和偏好 | - | - |
| knowledge_qa | `nodes/knowledge_qa_node.py` | agent | RAG增强的知识答疑 | 条件分支：task_type=知识答疑 | `config/knowledge_qa_llm_cfg.json` |
| study_plan | `nodes/study_plan_node.py` | agent | 目标拆解和学习路径规划 | 条件分支：task_type=学习计划 | `config/study_plan_llm_cfg.json` |
| error_analysis | `nodes/error_analysis_node.py` | agent | 错题分类和原因分析 | 条件分支：task_type=错题分析 | `config/error_analysis_llm_cfg.json` |
| learning_eval | `nodes/learning_eval_node.py` | agent | 学习效果分析和能力评分 | 条件分支：task_type=学习评价 | `config/learning_eval_llm_cfg.json` |
| resource_recommend | `nodes/resource_recommend_node.py` | agent | 个性化课程/资料/工具推荐 | - | `config/resource_recommend_llm_cfg.json` |
| plan_generation | `nodes/plan_generation_node.py` | agent | 生成个性化学习方案和报告 | - | `config/plan_generation_llm_cfg.json` |
| learning_record | `nodes/learning_record_node.py` | task | 汇总学习过程生成记录摘要 | - | - |

**类型说明**: task(task节点) / agent(大模型) / condition(条件分支) / looparray(列表循环) / loopcond(条件循环)

## 流程说明
```
入口 → student_profile → context_memory → [条件分支] → resource_recommend → plan_generation → learning_record → 结束
                                              ├→ knowledge_qa (知识答疑)
                                              ├→ study_plan (学习计划)
                                              ├→ error_analysis (错题分析)
                                              └→ learning_eval (学习评价)
```

## 技能使用
- 节点 `student_profile`、`knowledge_qa`、`study_plan`、`error_analysis`、`learning_eval`、`resource_recommend`、`plan_generation` 使用 **大语言模型** 技能
- 节点 `knowledge_qa` 同时使用 **知识库** 技能进行RAG知识增强
