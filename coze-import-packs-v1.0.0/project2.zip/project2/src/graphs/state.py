# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""智能学习助手 - 状态定义模块"""
from typing import Optional, List, Dict
from pydantic import BaseModel, Field


class GlobalState(BaseModel):
    """全局状态定义"""
    user_query: str = Field(default="", description="用户的学习问题或需求")
    student_info: str = Field(default="", description="学生基本信息（年级、科目等）")
    student_profile: Dict = Field(default={}, description="学生画像（学习能力、知识水平、学习习惯）")
    task_type: str = Field(default="", description="任务类型：知识答疑/学习计划/错题分析/学习评价")
    context_data: Dict = Field(default={}, description="上下文记忆数据（历史记录、偏好等）")
    knowledge_context: str = Field(default="", description="RAG检索的知识上下文")
    task_result: Dict = Field(default={}, description="任务执行结果")
    resources: List[Dict] = Field(default=[], description="推荐的学习资源列表")
    learning_plan: str = Field(default="", description="个性化学习方案")
    learning_report: str = Field(default="", description="阶段学习报告")
    record_summary: str = Field(default="", description="学习记录摘要")


class GraphInput(BaseModel):
    """工作流的输入"""
    user_query: str = Field(..., description="用户的学习问题或需求描述")
    student_info: str = Field(default="", description="学生基本信息，如年级、科目、学习目标等")


class GraphOutput(BaseModel):
    """工作流的输出"""
    learning_plan: str = Field(..., description="个性化学习方案")
    learning_report: str = Field(..., description="阶段学习报告")
    resources: List[Dict] = Field(default=[], description="推荐的学习资源列表")
    task_result: Dict = Field(default={}, description="任务执行结果详情")


# ============ 任务路由条件判断 ============

class TaskRouterState(BaseModel):
    """任务路由条件判断的输入"""
    task_type: str = Field(..., description="任务类型：知识答疑/学习计划/错题分析/学习评价")


# ============ 学生画像分析节点 ============

class StudentProfileInput(BaseModel):
    """学生画像分析节点的输入"""
    user_query: str = Field(..., description="用户的学习问题或需求")
    student_info: str = Field(default="", description="学生基本信息")


class StudentProfileOutput(BaseModel):
    """学生画像分析节点的输出"""
    student_profile: Dict = Field(..., description="学生画像，包含学习能力、知识水平、学习习惯")
    task_type: str = Field(..., description="判断的任务类型：知识答疑/学习计划/错题分析/学习评价")


# ============ 上下文记忆管理节点 ============

class ContextMemoryInput(BaseModel):
    """上下文记忆管理节点的输入"""
    student_profile: Dict = Field(..., description="学生画像")
    user_query: str = Field(..., description="用户的学习问题")
    task_type: str = Field(..., description="任务类型")


class ContextMemoryOutput(BaseModel):
    """上下文记忆管理节点的输出"""
    context_data: Dict = Field(..., description="整合后的上下文数据")


# ============ 知识答疑节点 ============

class KnowledgeQAInput(BaseModel):
    """知识答疑节点的输入"""
    user_query: str = Field(..., description="用户的知识问题")
    context_data: Dict = Field(default={}, description="上下文数据")
    student_profile: Dict = Field(default={}, description="学生画像")


class KnowledgeQAOutput(BaseModel):
    """知识答疑节点的输出"""
    task_result: Dict = Field(..., description="答疑结果，包含知识点解析、解题步骤等")
    knowledge_context: str = Field(default="", description="RAG检索到的知识上下文")


# ============ 学习计划节点 ============

class StudyPlanInput(BaseModel):
    """学习计划节点的输入"""
    user_query: str = Field(..., description="用户的学习目标或需求")
    context_data: Dict = Field(default={}, description="上下文数据")
    student_profile: Dict = Field(default={}, description="学生画像")


class StudyPlanOutput(BaseModel):
    """学习计划节点的输出"""
    task_result: Dict = Field(..., description="学习计划结果，包含目标拆解、任务安排、路径规划")


# ============ 错题分析节点 ============

class ErrorAnalysisInput(BaseModel):
    """错题分析节点的输入"""
    user_query: str = Field(..., description="用户的错题或薄弱知识点")
    context_data: Dict = Field(default={}, description="上下文数据")
    student_profile: Dict = Field(default={}, description="学生画像")


class ErrorAnalysisOutput(BaseModel):
    """错题分析节点的输出"""
    task_result: Dict = Field(..., description="错题分析结果，包含错因分析、强化训练建议")


# ============ 学习评价节点 ============

class LearningEvalInput(BaseModel):
    """学习评价节点的输入"""
    user_query: str = Field(..., description="用户的学习情况描述")
    context_data: Dict = Field(default={}, description="上下文数据")
    student_profile: Dict = Field(default={}, description="学生画像")


class LearningEvalOutput(BaseModel):
    """学习评价节点的输出"""
    task_result: Dict = Field(..., description="学习评价结果，包含效果分析、能力评分、改进建议")


# ============ 资源推荐节点 ============

class ResourceRecommendInput(BaseModel):
    """资源推荐节点的输入"""
    task_result: Dict = Field(..., description="任务执行结果")
    student_profile: Dict = Field(..., description="学生画像")
    task_type: str = Field(..., description="任务类型")


class ResourceRecommendOutput(BaseModel):
    """资源推荐节点的输出"""
    resources: List[Dict] = Field(..., description="推荐的学习资源列表，包含课程、资料、工具")


# ============ 方案生成节点 ============

class PlanGenerationInput(BaseModel):
    """方案生成节点的输入"""
    task_result: Dict = Field(..., description="任务执行结果")
    student_profile: Dict = Field(..., description="学生画像")
    resources: List[Dict] = Field(default=[], description="推荐的学习资源")
    task_type: str = Field(..., description="任务类型")


class PlanGenerationOutput(BaseModel):
    """方案生成节点的输出"""
    learning_plan: str = Field(..., description="个性化学习方案")
    learning_report: str = Field(..., description="阶段学习报告")


# ============ 学习记录节点 ============

class LearningRecordInput(BaseModel):
    """学习记录节点的输入"""
    user_query: str = Field(..., description="用户原始问题")
    student_profile: Dict = Field(default={}, description="学生画像")
    task_type: str = Field(default="", description="任务类型")
    task_result: Dict = Field(default={}, description="任务执行结果")
    resources: List[Dict] = Field(default=[], description="推荐资源")
    learning_plan: str = Field(default="", description="学习方案")
    learning_report: str = Field(default="", description="学习报告")


class LearningRecordOutput(BaseModel):
    """学习记录节点的输出"""
    record_summary: str = Field(..., description="学习记录摘要")
