# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""智能学习助手 - 主图编排"""
from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context

from graphs.state import (
    GlobalState,
    GraphInput,
    GraphOutput,
    TaskRouterState
)

# 导入节点函数
from graphs.nodes.student_profile_node import student_profile_node
from graphs.nodes.context_memory_node import context_memory_node
from graphs.nodes.knowledge_qa_node import knowledge_qa_node
from graphs.nodes.study_plan_node import study_plan_node
from graphs.nodes.error_analysis_node import error_analysis_node
from graphs.nodes.learning_eval_node import learning_eval_node
from graphs.nodes.resource_recommend_node import resource_recommend_node
from graphs.nodes.plan_generation_node import plan_generation_node
from graphs.nodes.learning_record_node import learning_record_node


def task_router(state: TaskRouterState) -> str:
    """
    title: 任务路由判断
    desc: 根据学生画像分析节点判断的任务类型，决定进入哪个子模块处理
    """
    task_type = state.task_type
    if task_type == "知识答疑":
        return "知识答疑"
    elif task_type == "学习计划":
        return "学习计划"
    elif task_type == "错题分析":
        return "错题分析"
    elif task_type == "学习评价":
        return "学习评价"
    else:
        return "知识答疑"


# 创建状态图
builder = StateGraph(GlobalState, input_schema=GraphInput, output_schema=GraphOutput)

# 添加节点
builder.add_node("student_profile", student_profile_node, metadata={
    "type": "agent",
    "llm_cfg": "config/student_profile_llm_cfg.json"
})
builder.add_node("context_memory", context_memory_node)
builder.add_node("knowledge_qa", knowledge_qa_node, metadata={
    "type": "agent",
    "llm_cfg": "config/knowledge_qa_llm_cfg.json"
})
builder.add_node("study_plan", study_plan_node, metadata={
    "type": "agent",
    "llm_cfg": "config/study_plan_llm_cfg.json"
})
builder.add_node("error_analysis", error_analysis_node, metadata={
    "type": "agent",
    "llm_cfg": "config/error_analysis_llm_cfg.json"
})
builder.add_node("learning_eval", learning_eval_node, metadata={
    "type": "agent",
    "llm_cfg": "config/learning_eval_llm_cfg.json"
})
builder.add_node("resource_recommend", resource_recommend_node, metadata={
    "type": "agent",
    "llm_cfg": "config/resource_recommend_llm_cfg.json"
})
builder.add_node("plan_generation", plan_generation_node, metadata={
    "type": "agent",
    "llm_cfg": "config/plan_generation_llm_cfg.json"
})
builder.add_node("learning_record", learning_record_node)

# 设置入口点
builder.set_entry_point("student_profile")

# 添加边：student_profile -> context_memory
builder.add_edge("student_profile", "context_memory")

# 添加条件分支：context_memory -> 4个子模块之一
builder.add_conditional_edges(
    source="context_memory",
    path=task_router,
    path_map={
        "知识答疑": "knowledge_qa",
        "学习计划": "study_plan",
        "错题分析": "error_analysis",
        "学习评价": "learning_eval"
    }
)

# 4个子模块汇聚到 resource_recommend
builder.add_edge("knowledge_qa", "resource_recommend")
builder.add_edge("study_plan", "resource_recommend")
builder.add_edge("error_analysis", "resource_recommend")
builder.add_edge("learning_eval", "resource_recommend")

# 后续边
builder.add_edge("resource_recommend", "plan_generation")
builder.add_edge("plan_generation", "learning_record")
builder.add_edge("learning_record", END)

# 编译图
main_graph = builder.compile()
