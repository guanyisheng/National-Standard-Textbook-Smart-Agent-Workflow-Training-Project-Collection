# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""上下文记忆管理节点 - 整合学生画像、历史学习记录和用户偏好"""
import json
from typing import Dict, Any
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import ContextMemoryInput, ContextMemoryOutput


def context_memory_node(
    state: ContextMemoryInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ContextMemoryOutput:
    """
    title: 上下文记忆管理
    desc: 整合学生画像、历史学习记录和用户偏好，构建完整的上下文记忆数据供后续节点使用
    """
    ctx = runtime.context

    # 构建上下文记忆数据
    student_profile: Dict[str, Any] = state.student_profile if isinstance(state.student_profile, dict) else {}
    user_query: str = state.user_query if isinstance(state.user_query, str) else ""
    task_type: str = state.task_type if isinstance(state.task_type, str) else "知识答疑"

    # 提取学生画像关键信息
    learning_ability: str = student_profile.get("learning_ability", "中等")
    knowledge_level: str = student_profile.get("knowledge_level", "待评估")
    learning_habits: str = student_profile.get("learning_habits", "待观察")
    strengths: list = student_profile.get("strengths", [])
    weaknesses: list = student_profile.get("weaknesses", [])

    # 构建上下文数据
    context_data: Dict[str, Any] = {
        "student_profile": {
            "learning_ability": learning_ability,
            "knowledge_level": knowledge_level,
            "learning_habits": learning_habits,
            "strengths": strengths if isinstance(strengths, list) else [],
            "weaknesses": weaknesses if isinstance(weaknesses, list) else []
        },
        "current_query": user_query,
        "task_type": task_type,
        "session_context": {
            "interaction_count": 1,
            "topics_discussed": [],
            "preferred_explanation_style": _infer_explanation_style(learning_ability),
            "difficulty_preference": _infer_difficulty(knowledge_level)
        },
        "learning_history": {
            "recent_topics": [],
            "mastered_concepts": strengths if isinstance(strengths, list) else [],
            "struggling_concepts": weaknesses if isinstance(weaknesses, list) else []
        }
    }

    return ContextMemoryOutput(context_data=context_data)


def _infer_explanation_style(learning_ability: str) -> str:
    """根据学习能力推断讲解风格"""
    ability = learning_ability.lower() if isinstance(learning_ability, str) else ""
    if "强" in ability or "高" in ability or "优秀" in ability:
        return "深度推导型"
    elif "弱" in ability or "低" in ability or "基础" in ability:
        return "循序渐进型"
    else:
        return "平衡型"


def _infer_difficulty(knowledge_level: str) -> str:
    """根据知识水平推断难度偏好"""
    level = knowledge_level.lower() if isinstance(knowledge_level, str) else ""
    if "高" in level or " advanced" in level or "精通" in level:
        return "进阶"
    elif "低" in level or "基础" in level or "入门" in level:
        return "基础"
    else:
        return "中等"
