# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""方案生成节点 - 生成个性化学习方案和阶段学习报告"""
import os
import json
from typing import Any, List, Dict
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from graphs.state import PlanGenerationInput, PlanGenerationOutput


def _extract_text(content: Any) -> str:
    """安全提取LLM返回的文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            parts = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            return " ".join(parts)
    return str(content)


def plan_generation_node(
    state: PlanGenerationInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> PlanGenerationOutput:
    """
    title: 方案生成
    desc: 综合任务执行结果、学生画像和推荐资源，生成个性化学习方案和阶段学习报告
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 读取LLM配置
    cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH", ""), config["metadata"]["llm_cfg"])
    with open(cfg_file, "r") as fd:
        llm_cfg = json.load(fd)

    llm_config = llm_cfg.get("config", {})
    sp = llm_cfg.get("sp", "")
    up_tpl_str = llm_cfg.get("up", "")

    # 渲染用户提示词
    up_tpl = Template(up_tpl_str)
    user_prompt = up_tpl.render(
        task_result=json.dumps(state.task_result, ensure_ascii=False, indent=2),
        student_profile=json.dumps(state.student_profile, ensure_ascii=False, indent=2),
        resources=json.dumps(state.resources, ensure_ascii=False, indent=2),
        task_type=state.task_type
    )

    # 调用LLM
    client = LLMClient(ctx=ctx)
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=user_prompt)
    ]

    model_id = llm_config.get("model", "doubao-seed-1-8-251228")
    temperature = llm_config.get("temperature", 0.5)
    max_tokens = llm_config.get("max_completion_tokens", 4096)

    response = client.invoke(
        messages=messages,
        model=model_id,
        temperature=temperature,
        max_completion_tokens=max_tokens
    )

    raw_text = _extract_text(response.content)

    # 解析结果
    try:
        text = raw_text.strip()
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0].strip()
        elif "```" in text:
            text = text.split("```")[1].split("```")[0].strip()
        result = json.loads(text)
        learning_plan = result.get("learning_plan", raw_text)
        learning_report = result.get("learning_report", "")
    except (json.JSONDecodeError, IndexError):
        learning_plan = raw_text
        learning_report = f"任务类型：{state.task_type}\n\n分析完成，已生成个性化学习方案。"

    if not isinstance(learning_plan, str):
        learning_plan = json.dumps(learning_plan, ensure_ascii=False, indent=2)
    if not isinstance(learning_report, str):
        learning_report = json.dumps(learning_report, ensure_ascii=False, indent=2)

    return PlanGenerationOutput(
        learning_plan=learning_plan,
        learning_report=learning_report
    )
