# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""学习记录节点 - 保存学习过程、完成情况和用户反馈"""
import json
from typing import Dict, List, Any
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import LearningRecordInput, LearningRecordOutput


def learning_record_node(
    state: LearningRecordInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> LearningRecordOutput:
    """
    title: 学习记录
    desc: 汇总本次学习过程的所有数据，生成学习记录摘要，包括学习过程、完成情况和关键成果
    """
    ctx = runtime.context

    # 提取各模块数据
    user_query: str = state.user_query if isinstance(state.user_query, str) else ""
    task_type: str = state.task_type if isinstance(state.task_type, str) else ""
    task_result: Dict[str, Any] = state.task_result if isinstance(state.task_result, dict) else {}
    resources: List[Dict] = state.resources if isinstance(state.resources, list) else []
    learning_plan: str = state.learning_plan if isinstance(state.learning_plan, str) else ""
    student_profile: Dict[str, Any] = state.student_profile if isinstance(state.student_profile, dict) else {}

    # 构建学习记录摘要
    record_parts: List[str] = []

    # 1. 基本信息
    record_parts.append("=== 学习记录 ===")
    record_parts.append(f"任务类型：{task_type}")
    record_parts.append(f"用户问题：{user_query[:100]}{'...' if len(user_query) > 100 else ''}")

    # 2. 学生画像摘要
    if student_profile:
        ability = student_profile.get("learning_ability", "未知")
        level = student_profile.get("knowledge_level", "未知")
        record_parts.append(f"学习能力：{ability}")
        record_parts.append(f"知识水平：{level}")

    # 3. 任务执行摘要
    if task_result:
        record_parts.append("\n--- 任务执行结果 ---")
        # 根据任务类型提取关键信息
        if task_type == "知识答疑":
            answer = task_result.get("answer", "")
            if isinstance(answer, str) and answer:
                record_parts.append(f"解答摘要：{answer[:200]}{'...' if len(answer) > 200 else ''}")
            kps = task_result.get("knowledge_points", [])
            if isinstance(kps, list) and kps:
                record_parts.append(f"涉及知识点：{', '.join(str(kp) for kp in kps[:5])}")
        elif task_type == "学习计划":
            goal = task_result.get("goal", "")
            if goal:
                record_parts.append(f"学习目标：{goal}")
            milestones = task_result.get("milestones", [])
            if isinstance(milestones, list) and milestones:
                record_parts.append(f"里程碑数量：{len(milestones)}")
        elif task_type == "错题分析":
            category = task_result.get("error_category", "")
            if category:
                record_parts.append(f"错题分类：{category}")
            cause = task_result.get("root_cause", "")
            if cause:
                record_parts.append(f"错因分析：{str(cause)[:200]}")
        elif task_type == "学习评价":
            assessment = task_result.get("overall_assessment", "")
            if assessment:
                record_parts.append(f"综合评价：{str(assessment)[:200]}")

    # 4. 资源推荐摘要
    if resources:
        record_parts.append(f"\n推荐资源数量：{len(resources)}")
        for i, res in enumerate(resources[:3]):
            if isinstance(res, dict):
                name = res.get("name", f"资源{i+1}")
                record_parts.append(f"  - {name}")

    # 5. 学习方案摘要
    if learning_plan:
        record_parts.append(f"\n学习方案已生成（{len(learning_plan)}字）")

    record_parts.append("\n=== 记录完毕 ===")

    record_summary = "\n".join(record_parts)

    return LearningRecordOutput(record_summary=record_summary)
