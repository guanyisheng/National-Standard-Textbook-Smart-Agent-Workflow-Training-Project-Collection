# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""知识答疑节点 - 基于RAG知识增强进行知识检索、难点解析和解题指导"""
import os
import json
from typing import Any
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient, KnowledgeClient, Config as KnowledgeConfig
from graphs.state import KnowledgeQAInput, KnowledgeQAOutput


def _extract_text(content: Any) -> str:
    """安全提取LLM返回的文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            parts = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            return " ".join(parts)
    return str(content)


def knowledge_qa_node(
    state: KnowledgeQAInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> KnowledgeQAOutput:
    """
    title: 知识答疑
    desc: 基于RAG知识增强，进行知识检索、难点解析和解题指导，为学生提供准确的知识解答
    integrations: 大语言模型, 知识库
    """
    ctx = runtime.context

    # 1. RAG知识检索
    knowledge_context = ""
    try:
        knowledge_client = KnowledgeClient(config=KnowledgeConfig(), ctx=ctx)
        search_response = knowledge_client.search(
            query=state.user_query,
            top_k=5,
            min_score=0.3
        )
        if search_response.code == 0 and search_response.chunks:
            knowledge_context = "\n\n".join(
                [chunk.content for chunk in search_response.chunks if chunk.content]
            )
    except Exception:
        knowledge_context = "（知识库暂无相关内容，将基于模型自身知识进行解答）"

    # 2. 读取LLM配置
    cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH", ""), config["metadata"]["llm_cfg"])
    with open(cfg_file, "r") as fd:
        llm_cfg = json.load(fd)

    llm_config = llm_cfg.get("config", {})
    sp = llm_cfg.get("sp", "")
    up_tpl_str = llm_cfg.get("up", "")

    # 3. 渲染用户提示词
    up_tpl = Template(up_tpl_str)
    user_prompt = up_tpl.render(
        user_query=state.user_query,
        knowledge_context=knowledge_context,
        student_profile=json.dumps(state.student_profile, ensure_ascii=False, indent=2),
        context_data=json.dumps(state.context_data, ensure_ascii=False, indent=2)
    )

    # 4. 调用LLM
    client = LLMClient(ctx=ctx)
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=user_prompt)
    ]

    model_id = llm_config.get("model", "doubao-seed-1-8-251228")
    temperature = llm_config.get("temperature", 0.3)
    max_tokens = llm_config.get("max_completion_tokens", 4096)

    response = client.invoke(
        messages=messages,
        model=model_id,
        temperature=temperature,
        max_completion_tokens=max_tokens
    )

    raw_text = _extract_text(response.content)

    # 5. 解析结果
    try:
        text = raw_text.strip()
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0].strip()
        elif "```" in text:
            text = text.split("```")[1].split("```")[0].strip()
        result = json.loads(text)
    except (json.JSONDecodeError, IndexError):
        result = {
            "answer": raw_text,
            "knowledge_points": [],
            "solution_steps": [],
            "difficulty_level": "中等",
            "key_concepts": []
        }

    return KnowledgeQAOutput(
        task_result=result,
        knowledge_context=knowledge_context
    )
