# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""学生画像分析节点 - 分析学生学习能力、知识水平、学习习惯，并判断任务类型"""
import os
import json
from typing import Dict, Any
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from graphs.state import StudentProfileInput, StudentProfileOutput


def _extract_text(content: Any) -> str:
    """安全提取LLM返回的文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            parts = [
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            return " ".join(parts)
    return str(content)


def student_profile_node(
    state: StudentProfileInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> StudentProfileOutput:
    """
    title: 学生画像分析
    desc: 分析学生的学习能力、知识水平和学习习惯，同时判断用户需求属于哪种任务类型（知识答疑/学习计划/错题分析/学习评价）
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 读取LLM配置
    cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH", ""), config["metadata"]["llm_cfg"])
    with open(cfg_file, "r") as fd:
        llm_cfg = json.load(fd)

    llm_config = llm_cfg.get("config", {})
    sp = llm_cfg.get("sp", "")
    up_tpl_str = llm_cfg.get("up", "")

    # 渲染用户提示词模板
    up_tpl = Template(up_tpl_str)
    user_prompt = up_tpl.render(
        user_query=state.user_query,
        student_info=state.student_info
    )

    # 调用LLM
    client = LLMClient(ctx=ctx)
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=user_prompt)
    ]

    model_id = llm_config.get("model", "doubao-seed-1-8-251228")
    temperature = llm_config.get("temperature", 0.3)
    max_tokens = llm_config.get("max_completion_tokens", 4096)

    response = client.invoke(
        messages=messages,
        model=model_id,
        temperature=temperature,
        max_completion_tokens=max_tokens
    )

    raw_text = _extract_text(response.content)

    # 解析LLM返回的JSON
    try:
        # 尝试提取JSON部分
        text = raw_text.strip()
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0].strip()
        elif "```" in text:
            text = text.split("```")[1].split("```")[0].strip()

        result = json.loads(text)
    except (json.JSONDecodeError, IndexError):
        # 兜底：使用默认结构
        result = {
            "student_profile": {
                "learning_ability": "中等",
                "knowledge_level": "待评估",
                "learning_habits": "待观察",
                "strengths": [],
                "weaknesses": []
            },
            "task_type": "知识答疑"
        }

    student_profile = result.get("student_profile", {})
    task_type = result.get("task_type", "知识答疑")

    # 校验task_type合法性
    valid_types = ["知识答疑", "学习计划", "错题分析", "学习评价"]
    if task_type not in valid_types:
        task_type = "知识答疑"

    return StudentProfileOutput(
        student_profile=student_profile,
        task_type=task_type
    )
