# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
from coze_coding_dev_sdk import SearchClient
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import SearchRelaxationInput, SearchRelaxationOutput


def search_relaxation_node(state: SearchRelaxationInput, config: RunnableConfig, runtime: Runtime[Context]) -> SearchRelaxationOutput:
    """
    title: 搜索放松技巧
    desc: 根据用户情绪状态，联网搜索适合的放松技巧和自助方法
    integrations: Web搜索
    """
    ctx = runtime.context

    # 根据情绪状态构建搜索关键词
    emotion = state.emotion_state
    query_map = {
        "焦虑": "缓解焦虑的放松技巧 深呼吸 冥想方法",
        "压力": "工作压力大如何放松 减压方法 放松技巧",
        "孤独": "缓解孤独感的方法 社交技巧 自我陪伴",
        "沮丧": "情绪低落怎么办 提升心情的方法 积极心态",
        "困惑": "理清思路的方法 决策分析技巧 自我反思",
        "愤怒": "如何控制情绪 愤怒管理技巧 冷静方法",
        "悲伤": "走出悲伤的方法 情绪调节技巧 自我疗愈",
        "矛盾": "如何处理内心冲突 决策困难怎么办 心理调适"
    }

    query = query_map.get(emotion, f"缓解{emotion}情绪的放松技巧 自助方法")

    # 执行搜索
    client = SearchClient(ctx=ctx)
    response = client.web_search(query=query, count=5, need_summary=True)

    # 整理搜索结果
    results_parts = []
    if response.summary:
        results_parts.append(f"【综合建议】{response.summary}")

    if response.web_items:
        for i, item in enumerate(response.web_items[:3], 1):
            title = item.title or "未知标题"
            snippet = item.snippet or ""
            url = item.url or ""
            results_parts.append(f"{i}. {title}\n   {snippet}\n   参考链接: {url}")

    search_results = "\n".join(results_parts) if results_parts else "暂未搜索到相关资源"

    return SearchRelaxationOutput(search_results=search_results)
