# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
from coze_coding_dev_sdk import SearchClient
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import SearchResourcesInput, SearchResourcesOutput


def search_resources_node(state: SearchResourcesInput, config: RunnableConfig, runtime: Runtime[Context]) -> SearchResourcesOutput:
    """
    title: 搜索心理资源
    desc: 根据用户的情绪状态和压力来源，搜索专业的心理调适方法和解决方案
    integrations: Web搜索
    """
    ctx = runtime.context

    # 构建搜索查询
    emotion = state.emotion_state
    stress = state.stress_source
    query = f"如何应对{emotion}情绪 {stress} 专业建议 心理调适方法"

    # 执行搜索
    client = SearchClient(ctx=ctx)
    response = client.web_search(query=query, count=5, need_summary=True)

    # 整理搜索结果
    results_parts = []
    if response.summary:
        results_parts.append(f"【专业建议摘要】{response.summary}")

    if response.web_items:
        for i, item in enumerate(response.web_items[:3], 1):
            title = item.title or "未知标题"
            snippet = item.snippet or ""
            url = item.url or ""
            results_parts.append(f"{i}. {title}\n   {snippet}\n   参考: {url}")

    search_results = "\n".join(results_parts) if results_parts else "暂未搜索到相关资源"

    return SearchResourcesOutput(search_results=search_results)
