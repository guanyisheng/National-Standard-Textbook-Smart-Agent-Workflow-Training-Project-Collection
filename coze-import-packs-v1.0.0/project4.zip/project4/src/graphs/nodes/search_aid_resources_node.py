# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
from coze_coding_dev_sdk import SearchClient
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import SearchAidResourcesInput, SearchAidResourcesOutput


def search_aid_resources_node(state: SearchAidResourcesInput, config: RunnableConfig, runtime: Runtime[Context]) -> SearchAidResourcesOutput:
    """
    title: 搜索援助资源
    desc: 搜索专业的心理援助资源、热线和专业机构信息
    integrations: Web搜索
    """
    ctx = runtime.context

    # 构建搜索查询
    query = "心理援助热线 免费咨询 24小时 心理危机干预 专业机构"

    # 执行搜索
    client = SearchClient(ctx=ctx)
    response = client.web_search(query=query, count=5, need_summary=True)

    # 整理搜索结果
    results_parts = []
    if response.summary:
        results_parts.append(f"【资源摘要】{response.summary}")

    if response.web_items:
        for i, item in enumerate(response.web_items[:3], 1):
            title = item.title or "未知标题"
            snippet = item.snippet or ""
            url = item.url or ""
            results_parts.append(f"{i}. {title}\n   {snippet}\n   链接: {url}")

    # 添加固定的援助热线信息
    hotline_info = """
【全国心理援助热线】
- 全国24小时心理援助热线：400-161-9995
- 北京心理危机研究与干预中心：010-82951332
- 生命热线：400-821-1215
- 希望24热线：400-161-9995
"""
    results_parts.append(hotline_info)

    search_results = "\n".join(results_parts) if results_parts else "暂未搜索到相关资源"

    return SearchAidResourcesOutput(search_results=search_results)
