# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
import os
import json
from jinja2 import Template
from coze_coding_dev_sdk import LLMClient
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import SuggestionGenerationInput, SuggestionGenerationOutput


def suggestion_generation_node(state: SuggestionGenerationInput, config: RunnableConfig, runtime: Runtime[Context]) -> SuggestionGenerationOutput:
    """
    title: 建议生成
    desc: 基于问题分析结果，为用户提供具体可行的建议方案
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 读取大模型配置文件
    cfg_file = os.path.join(os.getenv("COZE_WORKSPACE_PATH", ""), config["metadata"]["llm_cfg"])
    with open(cfg_file, "r", encoding="utf-8") as fd:
        llm_cfg = json.load(fd)

    llm_config = llm_cfg.get("config", {})
    sp = llm_cfg.get("sp", "")
    up = llm_cfg.get("up", "")

    # 使用jinja2模板渲染用户提示词
    up_tpl = Template(up)
    rendered_up = up_tpl.render({
        "user_message": state.user_message,
        "emotion_state": state.emotion_state,
        "stress_source": state.stress_source,
        "problem_analysis": state.problem_analysis
    })

    # 初始化LLM客户端
    client = LLMClient(ctx=ctx)

    # 构建消息并调用模型
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=rendered_up)
    ]

    response = client.invoke(
        messages=messages,
        model=llm_config.get("model", "doubao-seed-2-0-lite-260215"),
        temperature=llm_config.get("temperature", 0.6),
        top_p=llm_config.get("top_p", 0.9),
        max_completion_tokens=llm_config.get("max_completion_tokens", 4000),
        thinking=llm_config.get("thinking", "disabled")
    )

    # 安全提取响应内容
    raw_content = response.content
    content_str = ""
    if isinstance(raw_content, str):
        content_str = raw_content.strip()
    elif isinstance(raw_content, list):
        if raw_content and isinstance(raw_content[0], str):
            content_str = " ".join(raw_content).strip()
        else:
            text_parts = [
                item.get("text", "")
                for item in raw_content
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            content_str = " ".join(text_parts).strip()
    else:
        content_str = str(raw_content).strip()

    return SuggestionGenerationOutput(
        response_text=content_str,
        response_path="中度-深度分析"
    )
