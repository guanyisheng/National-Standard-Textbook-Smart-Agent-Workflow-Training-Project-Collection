# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
from typing import Optional, List
from pydantic import BaseModel, Field


class GlobalState(BaseModel):
    """全局状态定义"""
    user_message: str = Field(default="", description="用户输入的消息文本")
    emotion_state: str = Field(default="", description="识别到的情绪状态")
    need_type: str = Field(default="", description="用户需求类型")
    stress_source: str = Field(default="", description="压力来源分析")
    severity_level: str = Field(default="", description="情绪严重程度：轻度/中度/重度")
    analysis_summary: str = Field(default="", description="情绪分析摘要")
    problem_analysis: str = Field(default="", description="问题分析结果")
    companion_response: str = Field(default="", description="温暖陪伴回复")
    search_results: str = Field(default="", description="搜索结果")
    merged_response: str = Field(default="", description="合并后的回复")
    response_text: str = Field(default="", description="最终生成的回复文本")
    guide_url: str = Field(default="", description="情绪调节指南PDF链接")
    response_path: str = Field(default="", description="回复路径标识")


class GraphInput(BaseModel):
    """工作流的输入"""
    user_message: str = Field(..., description="用户输入的消息文本")


class GraphOutput(BaseModel):
    """工作流的输出"""
    emotion_state: str = Field(..., description="识别到的情绪状态")
    severity_level: str = Field(..., description="情绪严重程度")
    response_text: str = Field(..., description="生成的回复文本")
    guide_url: str = Field(default="", description="情绪调节指南PDF下载链接（中度路径）")
    response_path: str = Field(..., description="处理的分支路径")


class EmotionAnalysisInput(BaseModel):
    """情绪分析节点的输入"""
    user_message: str = Field(..., description="用户输入的消息文本")


class EmotionAnalysisOutput(BaseModel):
    """情绪分析节点的输出"""
    emotion_state: str = Field(..., description="识别到的情绪状态")
    need_type: str = Field(..., description="用户需求类型：倾诉/建议/解决问题/安慰")
    stress_source: str = Field(..., description="压力或困扰的来源分析")
    severity_level: str = Field(..., description="情绪严重程度：轻度/中度/重度")
    analysis_summary: str = Field(..., description="对用户当前状态的综合分析摘要")


class SeverityRouterInput(BaseModel):
    """严重程度路由节点的输入"""
    severity_level: str = Field(..., description="情绪严重程度")


class WarmCompanionInput(BaseModel):
    """温暖陪伴节点的输入"""
    user_message: str = Field(..., description="用户原始消息")
    emotion_state: str = Field(..., description="识别到的情绪状态")
    analysis_summary: str = Field(..., description="情绪分析摘要")


class WarmCompanionOutput(BaseModel):
    """温暖陪伴节点的输出"""
    companion_response: str = Field(..., description="温暖陪伴式回复")


class SearchRelaxationInput(BaseModel):
    """搜索放松技巧节点的输入"""
    emotion_state: str = Field(..., description="识别到的情绪状态")


class SearchRelaxationOutput(BaseModel):
    """搜索放松技巧节点的输出"""
    search_results: str = Field(..., description="搜索到的放松技巧和建议")


class MergeMildResponseInput(BaseModel):
    """合并轻度回复节点的输入"""
    user_message: str = Field(..., description="用户原始消息")
    emotion_state: str = Field(..., description="识别到的情绪状态")
    companion_response: str = Field(..., description="温暖陪伴回复")
    search_results: str = Field(..., description="搜索到的放松技巧")


class MergeMildResponseOutput(BaseModel):
    """合并轻度回复节点的输出"""
    response_text: str = Field(..., description="合并后的完整回复")
    response_path: str = Field(default="轻度-温暖陪伴+资源推荐", description="处理路径标识")


class ProblemAnalysisInput(BaseModel):
    """问题分析节点的输入"""
    user_message: str = Field(..., description="用户原始消息")
    emotion_state: str = Field(..., description="识别到的情绪状态")
    stress_source: str = Field(..., description="压力来源分析")
    analysis_summary: str = Field(..., description="情绪分析摘要")


class ProblemAnalysisOutput(BaseModel):
    """问题分析节点的输出"""
    problem_analysis: str = Field(..., description="问题梳理和分析结果")
    emotion_state: str = Field(..., description="情绪状态（传递给下游）")
    user_message: str = Field(..., description="用户原始消息（传递给下游）")
    stress_source: str = Field(..., description="压力来源（传递给下游）")


class SearchResourcesInput(BaseModel):
    """搜索心理资源节点的输入"""
    emotion_state: str = Field(..., description="识别到的情绪状态")
    stress_source: str = Field(..., description="压力来源分析")


class SearchResourcesOutput(BaseModel):
    """搜索心理资源节点的输出"""
    search_results: str = Field(..., description="搜索到的心理调适资源和方法")


class SuggestionGenerationInput(BaseModel):
    """建议生成节点的输入"""
    user_message: str = Field(..., description="用户原始消息")
    emotion_state: str = Field(..., description="识别到的情绪状态")
    stress_source: str = Field(..., description="压力来源分析")
    problem_analysis: str = Field(..., description="问题分析结果")
    search_results: str = Field(..., description="搜索到的资源和方法")


class SuggestionGenerationOutput(BaseModel):
    """建议生成节点的输出"""
    response_text: str = Field(..., description="包含建议的完整回复")


class GenerateGuideInput(BaseModel):
    """生成情绪调节指南节点的输入"""
    user_message: str = Field(..., description="用户原始消息")
    emotion_state: str = Field(..., description="识别到的情绪状态")
    response_text: str = Field(..., description="建议回复文本")


class GenerateGuideOutput(BaseModel):
    """生成情绪调节指南节点的输出"""
    guide_url: str = Field(..., description="情绪调节指南PDF下载链接")
    response_path: str = Field(default="中度-深度分析+指南", description="处理路径标识")


class ProfessionalGuidanceInput(BaseModel):
    """专业引导节点的输入"""
    user_message: str = Field(..., description="用户原始消息")
    emotion_state: str = Field(..., description="识别到的情绪状态")
    stress_source: str = Field(..., description="压力来源分析")
    analysis_summary: str = Field(..., description="情绪分析摘要")


class ProfessionalGuidanceOutput(BaseModel):
    """专业引导节点的输出"""
    companion_response: str = Field(..., description="专业引导式回复")


class SearchAidResourcesInput(BaseModel):
    """搜索援助资源节点的输入"""
    emotion_state: str = Field(..., description="识别到的情绪状态")


class SearchAidResourcesOutput(BaseModel):
    """搜索援助资源节点的输出"""
    search_results: str = Field(..., description="搜索到的心理援助资源")


class MergeSevereResponseInput(BaseModel):
    """合并重度回复节点的输入"""
    user_message: str = Field(..., description="用户原始消息")
    emotion_state: str = Field(..., description="识别到的情绪状态")
    companion_response: str = Field(..., description="专业引导回复")
    search_results: str = Field(..., description="搜索到的援助资源")


class MergeSevereResponseOutput(BaseModel):
    """合并重度回复节点的输出"""
    response_text: str = Field(..., description="合并后的完整回复")
    response_path: str = Field(default="重度-专业引导+资源", description="处理路径标识")
