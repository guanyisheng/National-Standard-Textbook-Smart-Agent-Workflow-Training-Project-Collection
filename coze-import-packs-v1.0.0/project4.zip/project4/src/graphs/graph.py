# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
from langgraph.graph import StateGraph, END
from graphs.state import (
    GlobalState,
    GraphInput,
    GraphOutput,
    SeverityRouterInput,
)
from graphs.nodes.emotion_analysis_node import emotion_analysis_node
from graphs.nodes.warm_companion_node import warm_companion_node
from graphs.nodes.search_relaxation_node import search_relaxation_node
from graphs.nodes.merge_mild_response_node import merge_mild_response_node
from graphs.nodes.problem_analysis_node import problem_analysis_node
from graphs.nodes.search_resources_node import search_resources_node
from graphs.nodes.suggestion_generation_node import suggestion_generation_node
from graphs.nodes.generate_guide_node import generate_guide_node
from graphs.nodes.professional_guidance_node import professional_guidance_node
from graphs.nodes.search_aid_resources_node import search_aid_resources_node
from graphs.nodes.merge_severe_response_node import merge_severe_response_node


# 条件路由函数：根据情绪严重程度决定走哪条分支
def severity_router(state: SeverityRouterInput) -> str:
    """
    title: 严重程度路由
    desc: 根据情绪严重程度判断走轻度陪伴、中度分析还是重度专业引导分支
    """
    severity = state.severity_level
    if severity == "轻度":
        return "轻度陪伴"
    elif severity == "中度":
        return "中度分析"
    else:
        return "重度引导"


# 创建状态图，指定全局状态、入参和出参
builder = StateGraph(GlobalState, input_schema=GraphInput, output_schema=GraphOutput)

# 添加所有节点
builder.add_node("emotion_analysis", emotion_analysis_node, metadata={"type": "agent", "llm_cfg": "config/emotion_analysis_llm_cfg.json"})
builder.add_node("warm_companion", warm_companion_node, metadata={"type": "agent", "llm_cfg": "config/warm_companion_llm_cfg.json"})
builder.add_node("search_relaxation", search_relaxation_node)
builder.add_node("merge_mild_response", merge_mild_response_node, metadata={"type": "agent", "llm_cfg": "config/merge_mild_response_llm_cfg.json"})
builder.add_node("problem_analysis", problem_analysis_node, metadata={"type": "agent", "llm_cfg": "config/problem_analysis_llm_cfg.json"})
builder.add_node("search_resources", search_resources_node)
builder.add_node("suggestion_generation", suggestion_generation_node, metadata={"type": "agent", "llm_cfg": "config/suggestion_generation_llm_cfg.json"})
builder.add_node("generate_guide", generate_guide_node)
builder.add_node("professional_guidance", professional_guidance_node, metadata={"type": "agent", "llm_cfg": "config/professional_guidance_llm_cfg.json"})
builder.add_node("search_aid_resources", search_aid_resources_node)
builder.add_node("merge_severe_response", merge_severe_response_node, metadata={"type": "agent", "llm_cfg": "config/merge_severe_response_llm_cfg.json"})

# 设置入口点
builder.set_entry_point("emotion_analysis")

# 添加条件分支：根据严重程度路由到不同处理路径
builder.add_conditional_edges(
    source="emotion_analysis",
    path=severity_router,
    path_map={
        "轻度陪伴": "warm_companion",
        "中度分析": "problem_analysis",
        "重度引导": "professional_guidance"
    }
)

# ===== 轻度路径：并行处理 =====
# warm_companion -> search_relaxation (并行)
builder.add_edge("warm_companion", "search_relaxation")
# search_relaxation -> merge_mild_response (合并)
builder.add_edge("search_relaxation", "merge_mild_response")
builder.add_edge("merge_mild_response", END)

# ===== 中度路径：链式处理 =====
# problem_analysis -> search_resources -> suggestion_generation -> generate_guide
builder.add_edge("problem_analysis", "search_resources")
builder.add_edge("search_resources", "suggestion_generation")
builder.add_edge("suggestion_generation", "generate_guide")
builder.add_edge("generate_guide", END)

# ===== 重度路径：并行处理 =====
# professional_guidance -> search_aid_resources (并行)
builder.add_edge("professional_guidance", "search_aid_resources")
# search_aid_resources -> merge_severe_response (合并)
builder.add_edge("search_aid_resources", "merge_severe_response")
builder.add_edge("merge_severe_response", END)

# 编译图
main_graph = builder.compile()
