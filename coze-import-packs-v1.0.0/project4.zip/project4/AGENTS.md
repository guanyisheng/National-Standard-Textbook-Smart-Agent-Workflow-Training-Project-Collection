## 项目概述
- **名称**: 情感陪伴与心理支持工作流（高级多技能版）
- **功能**: 智能分析用户情绪，通过条件分支路由，结合Web搜索和文档生成等多种技能，提供差异化的情感支持

### 工作流架构
```
用户输入 → 情绪分析(Agent) → 严重程度路由(条件分支)
    ├── 🟢 轻度 → 温暖陪伴(Agent) → 搜索放松技巧(搜索) → 合并回复(Agent)
    ├── 🟡 中度 → 问题分析(Agent) → 搜索资源(搜索) → 建议生成(Agent) → 生成PDF指南(文档)
    └── 🔴 重度 → 专业引导(Agent) → 搜索援助资源(搜索) → 合并回复(Agent)
```

### 节点清单
| 节点名 | 文件位置 | 类型 | 功能描述 | 分支逻辑 | 配置文件 |
|-------|---------|------|---------|---------|---------|
| emotion_analysis | `nodes/emotion_analysis_node.py` | agent | 分析情绪状态、需求类型、严重程度 | - | `config/emotion_analysis_llm_cfg.json` |
| severity_router | `graph.py` | condition | 根据严重程度路由到不同分支 | 轻度→warm_companion, 中度→problem_analysis, 重度→professional_guidance | - |
| warm_companion | `nodes/warm_companion_node.py` | agent | 轻度情绪：温暖陪伴式回复 | - | `config/warm_companion_llm_cfg.json` |
| search_relaxation | `nodes/search_relaxation_node.py` | task | 轻度路径：搜索放松技巧资源 | - | - |
| merge_mild_response | `nodes/merge_mild_response_node.py` | agent | 轻度路径：合并陪伴回复与搜索资源 | - | `config/merge_mild_response_llm_cfg.json` |
| problem_analysis | `nodes/problem_analysis_node.py` | agent | 中度情绪：深度问题分析 | - | `config/problem_analysis_llm_cfg.json` |
| search_resources | `nodes/search_resources_node.py` | task | 中度路径：搜索心理调适资源 | - | - |
| suggestion_generation | `nodes/suggestion_generation_node.py` | agent | 中度路径：基于分析和资源生成建议 | - | `config/suggestion_generation_llm_cfg.json` |
| generate_guide | `nodes/generate_guide_node.py` | task | 中度路径：生成个性化PDF情绪调节指南 | - | - |
| professional_guidance | `nodes/professional_guidance_node.py` | agent | 重度情绪：专业引导回复 | - | `config/professional_guidance_llm_cfg.json` |
| search_aid_resources | `nodes/search_aid_resources_node.py` | task | 重度路径：搜索心理援助资源 | - | - |
| merge_severe_response | `nodes/merge_severe_response_node.py` | agent | 重度路径：合并专业回复与援助资源 | - | `config/merge_severe_response_llm_cfg.json` |

**类型说明**: task(task节点) / agent(大模型) / condition(条件分支) / looparray(列表循环) / loopcond(条件循环)

## 子图清单
无

## 技能使用
- **大语言模型**：emotion_analysis, warm_companion, problem_analysis, suggestion_generation, professional_guidance, merge_mild_response, merge_severe_response
- **Web搜索**：search_relaxation(搜索放松技巧), search_resources(搜索心理资源), search_aid_resources(搜索援助资源)
- **文档生成**：generate_guide(生成PDF情绪调节指南)
