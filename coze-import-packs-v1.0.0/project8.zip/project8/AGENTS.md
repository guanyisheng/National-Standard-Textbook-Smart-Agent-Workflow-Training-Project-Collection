## 项目概述
- **名称**: 企业AI数字员工综合应用平台
- **功能**: 多Agent协同的企业智能助手，支持行政、人事、财务、业务四大数字员工，集成知识库RAG增强

### 节点清单
| 节点名 | 文件位置 | 类型 | 功能描述 | 分支逻辑 | 配置文件 |
|-------|---------|------|---------|---------|---------|
| intent_recognition | `nodes/intent_recognition_node.py` | agent | 识别用户意图分类（行政/人事/财务/业务） | - | `config/intent_recognition_llm_cfg.json` |
| knowledge_retrieval | `nodes/knowledge_retrieval_node.py` | task | 知识库RAG语义检索，为Agent提供知识增强 | - | - |
| admin_assistant | `nodes/admin_assistant_node.py` | agent | 行政助手：文件处理、会议安排、通知生成 | - | `config/admin_assistant_llm_cfg.json` |
| hr_assistant | `nodes/hr_assistant_node.py` | agent | 人事助手：简历筛选、员工查询、培训规划 | - | `config/hr_assistant_llm_cfg.json` |
| finance_assistant | `nodes/finance_assistant_node.py` | agent | 财务助手：数据统计、报表分析、财务咨询 | - | `config/finance_assistant_llm_cfg.json` |
| business_assistant | `nodes/business_assistant_node.py` | agent | 业务助手：客户分析、销售辅助、业务预测 | - | `config/business_assistant_llm_cfg.json` |
| result_summary | `nodes/result_summary_node.py` | agent | 整合Agent结果和知识库信息，生成最终回复 | - | `config/result_summary_llm_cfg.json` |

**类型说明**: task(task节点) / agent(大模型) / condition(条件分支) / looparray(列表循环) / loopcond(条件循环)

### 条件分支
| 源节点 | 条件函数 | 分支映射 |
|-------|---------|---------|
| knowledge_retrieval | route_dispatch_func | "行政助手"→admin_assistant, "人事助手"→hr_assistant, "财务助手"→finance_assistant, "业务助手"→business_assistant |

## 子图清单
无

## 技能使用
- 节点`intent_recognition`、`admin_assistant`、`hr_assistant`、`finance_assistant`、`business_assistant`、`result_summary`使用大语言模型技能
- 节点`knowledge_retrieval`使用知识库技能（RAG语义搜索）

## 工作流架构
```
用户输入 → 意图识别Agent → 知识库检索(RAG) → 条件路由 → 对应Agent处理 → 结果汇总 → 输出
                                                    ↓
                                    ┌───────────────┼───────────────┬───────────────┐
                                    ↓               ↓               ↓               ↓
                              行政助手Agent    人事助手Agent    财务助手Agent    业务助手Agent
```
