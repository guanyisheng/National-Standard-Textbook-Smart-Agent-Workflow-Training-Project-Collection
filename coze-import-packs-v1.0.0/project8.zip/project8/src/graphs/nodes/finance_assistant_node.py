# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
财务助手Agent节点 - 处理数据统计、报表分析、财务咨询等财务事务
"""
import os
import json
from jinja2 import Template
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from graphs.state import FinanceAssistantInput, FinanceAssistantOutput


def get_text_content(content) -> str:
    """安全提取LLM响应文本"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            return " ".join(
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            )
    return str(content)


def finance_assistant_node(
    state: FinanceAssistantInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> FinanceAssistantOutput:
    """
    title: 财务助手
    desc: 处理数据统计、报表分析、财务咨询等财务事务，提供专业财务支持
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 读取LLM配置
    cfg_file = os.path.join(
        os.getenv("COZE_WORKSPACE_PATH", ""),
        config["metadata"]["llm_cfg"]
    )
    with open(cfg_file, "r", encoding="utf-8") as fd:
        llm_cfg = json.load(fd)

    llm_config = llm_cfg.get("config", {})
    sp = llm_cfg.get("sp", "")
    up_tpl_str = llm_cfg.get("up", "")

    # 渲染用户提示词
    up_tpl = Template(up_tpl_str)
    up_rendered = up_tpl.render(
        user_input=state.user_input,
        intent_detail=state.intent_detail,
        knowledge_context=state.knowledge_context
    )

    # 调用LLM
    client = LLMClient(ctx=ctx)
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=up_rendered)
    ]

    response = client.invoke(
        messages=messages,
        model=llm_config.get("model", "doubao-seed-2-0-lite-260215"),
        temperature=llm_config.get("temperature", 0.2),
        max_completion_tokens=llm_config.get("max_completion_tokens", 2000)
    )

    raw_text = get_text_content(response.content)

    # 解析返回结果
    try:
        json_start = raw_text.find("{")
        json_end = raw_text.rfind("}") + 1
        if json_start >= 0 and json_end > json_start:
            json_str = raw_text[json_start:json_end]
            result = json.loads(json_str)
        else:
            result = json.loads(raw_text)

        agent_response = result.get("response", raw_text)
        data_summary = result.get("data_summary", None)
    except (json.JSONDecodeError, ValueError):
        agent_response = raw_text
        data_summary = None

    return FinanceAssistantOutput(
        agent_response=agent_response,
        agent_name="财务助手",
        data_summary=data_summary
    )
