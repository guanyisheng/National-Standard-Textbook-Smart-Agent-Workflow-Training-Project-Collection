# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
知识库检索节点 - 使用RAG检索企业知识库，为Agent提供上下文支持
"""
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import KnowledgeClient, Config
from graphs.state import KnowledgeRetrievalInput, KnowledgeRetrievalOutput


def knowledge_retrieval_node(
    state: KnowledgeRetrievalInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> KnowledgeRetrievalOutput:
    """
    title: 知识库检索
    desc: 基于用户查询进行语义搜索，从企业知识库中检索相关信息，为Agent提供知识增强
    integrations: 知识库
    """
    ctx = runtime.context

    query = state.user_input
    intent_category = state.intent_category

    # 构建增强的查询（结合意图分类）
    enhanced_query = query
    if intent_category:
        enhanced_query = f"{intent_category}相关：{query}"

    try:
        # 初始化知识库客户端
        kb_config = Config()
        kb_client = KnowledgeClient(config=kb_config, ctx=ctx)

        # 执行语义搜索
        search_response = kb_client.search(
            query=enhanced_query,
            top_k=3,
            min_score=0.3
        )

        if search_response.code == 0 and search_response.chunks:
            # 拼接检索到的知识内容
            knowledge_parts = []
            for i, chunk in enumerate(search_response.chunks):
                content = chunk.content if chunk.content else ""
                score = chunk.score if chunk.score else 0.0
                if content.strip():
                    knowledge_parts.append(f"[知识{i+1}](相关度:{score:.2f}) {content.strip()}")

            knowledge_context = "\n".join(knowledge_parts)
            source_count = len(knowledge_parts)
        else:
            knowledge_context = ""
            source_count = 0

    except Exception as e:
        # 知识库检索失败时，不影响主流程
        knowledge_context = ""
        source_count = 0

    return KnowledgeRetrievalOutput(
        knowledge_context=knowledge_context,
        source_count=source_count
    )
