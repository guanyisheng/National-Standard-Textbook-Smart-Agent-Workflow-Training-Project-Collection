# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
企业AI数字员工综合应用平台 - 状态定义
"""
from typing import Optional, List, Dict, Literal
from pydantic import BaseModel, Field


class GlobalState(BaseModel):
    """全局状态定义 - 工作流运行过程中的共享状态"""
    # 用户输入
    user_input: str = Field(default="", description="用户原始输入")
    user_type: str = Field(default="", description="用户类型：员工/管理人员/客户")
    
    # 意图识别结果
    intent_category: str = Field(default="", description="意图分类：行政/人事/财务/业务")
    intent_detail: str = Field(default="", description="意图详细描述")
    
    # Agent处理结果
    agent_response: str = Field(default="", description="Agent处理结果")
    agent_name: str = Field(default="", description="处理该请求的Agent名称")
    
    # 知识库检索结果
    knowledge_context: str = Field(default="", description="知识库检索到的相关信息")
    
    # 最终输出
    final_response: str = Field(default="", description="最终回复内容")
    suggestions: List[str] = Field(default=[], description="后续建议列表")


class GraphInput(BaseModel):
    """工作流输入"""
    user_input: str = Field(..., description="用户输入的问题或请求")
    user_type: Optional[str] = Field(default="员工", description="用户类型：员工/管理人员/客户")


class GraphOutput(BaseModel):
    """工作流输出"""
    final_response: str = Field(..., description="最终回复内容")
    agent_name: str = Field(default="", description="处理该请求的Agent名称")
    suggestions: List[str] = Field(default=[], description="后续建议列表")


# ============ 意图识别节点 ============
class IntentRecognitionInput(BaseModel):
    """意图识别节点输入"""
    user_input: str = Field(..., description="用户原始输入")
    user_type: str = Field(default="员工", description="用户类型")


class IntentRecognitionOutput(BaseModel):
    """意图识别节点输出"""
    intent_category: str = Field(..., description="意图分类：行政/人事/财务/业务")
    intent_detail: str = Field(..., description="意图详细描述")
    confidence: float = Field(default=0.0, description="识别置信度")


# ============ 路由分发节点 ============
class RouteDispatchInput(BaseModel):
    """路由分发节点输入"""
    intent_category: str = Field(..., description="意图分类")


class RouteDispatchOutput(BaseModel):
    """路由分发节点输出"""
    target_agent: str = Field(..., description="目标Agent名称")


# ============ 行政助手节点 ============
class AdminAssistantInput(BaseModel):
    """行政助手节点输入"""
    user_input: str = Field(..., description="用户原始输入")
    intent_detail: str = Field(default="", description="意图详细描述")
    knowledge_context: str = Field(default="", description="知识库上下文")


class AdminAssistantOutput(BaseModel):
    """行政助手节点输出"""
    agent_response: str = Field(..., description="行政助手处理结果")
    agent_name: str = Field(default="行政助手", description="Agent名称")
    action_items: List[str] = Field(default=[], description="待办事项列表")


# ============ 人事助手节点 ============
class HRAssistantInput(BaseModel):
    """人事助手节点输入"""
    user_input: str = Field(..., description="用户原始输入")
    intent_detail: str = Field(default="", description="意图详细描述")
    knowledge_context: str = Field(default="", description="知识库上下文")


class HRAssistantOutput(BaseModel):
    """人事助手节点输出"""
    agent_response: str = Field(..., description="人事助手处理结果")
    agent_name: str = Field(default="人事助手", description="Agent名称")
    candidate_info: Optional[Dict] = Field(default=None, description="候选人信息")


# ============ 财务助手节点 ============
class FinanceAssistantInput(BaseModel):
    """财务助手节点输入"""
    user_input: str = Field(..., description="用户原始输入")
    intent_detail: str = Field(default="", description="意图详细描述")
    knowledge_context: str = Field(default="", description="知识库上下文")


class FinanceAssistantOutput(BaseModel):
    """财务助手节点输出"""
    agent_response: str = Field(..., description="财务助手处理结果")
    agent_name: str = Field(default="财务助手", description="Agent名称")
    data_summary: Optional[Dict] = Field(default=None, description="数据摘要")


# ============ 业务助手节点 ============
class BusinessAssistantInput(BaseModel):
    """业务助手节点输入"""
    user_input: str = Field(..., description="用户原始输入")
    intent_detail: str = Field(default="", description="意图详细描述")
    knowledge_context: str = Field(default="", description="知识库上下文")


class BusinessAssistantOutput(BaseModel):
    """业务助手节点输出"""
    agent_response: str = Field(..., description="业务助手处理结果")
    agent_name: str = Field(default="业务助手", description="Agent名称")
    business_insights: List[str] = Field(default=[], description="业务洞察")


# ============ 知识库检索节点 ============
class KnowledgeRetrievalInput(BaseModel):
    """知识库检索节点输入"""
    user_input: str = Field(..., description="用户原始输入，作为检索查询")
    intent_category: str = Field(default="", description="意图分类")


class KnowledgeRetrievalOutput(BaseModel):
    """知识库检索节点输出"""
    knowledge_context: str = Field(..., description="检索到的知识内容")
    source_count: int = Field(default=0, description="检索到的来源数量")


# ============ 结果汇总节点 ============
class ResultSummaryInput(BaseModel):
    """结果汇总节点输入"""
    user_input: str = Field(..., description="用户原始输入")
    agent_response: str = Field(..., description="Agent处理结果")
    agent_name: str = Field(default="", description="Agent名称")
    knowledge_context: str = Field(default="", description="知识库上下文")


class ResultSummaryOutput(BaseModel):
    """结果汇总节点输出"""
    final_response: str = Field(..., description="最终回复内容")
    suggestions: List[str] = Field(default=[], description="后续建议列表")
