# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
企业AI数字员工综合应用平台 - 主图编排
"""
from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import (
    GlobalState,
    GraphInput,
    GraphOutput,
    RouteDispatchInput
)

# 导入节点函数
from graphs.nodes.intent_recognition_node import intent_recognition_node
from graphs.nodes.admin_assistant_node import admin_assistant_node
from graphs.nodes.hr_assistant_node import hr_assistant_node
from graphs.nodes.finance_assistant_node import finance_assistant_node
from graphs.nodes.business_assistant_node import business_assistant_node
from graphs.nodes.knowledge_retrieval_node import knowledge_retrieval_node
from graphs.nodes.result_summary_node import result_summary_node


def route_dispatch_func(state: RouteDispatchInput) -> str:
    """
    title: 路由分发
    desc: 根据意图分类将请求路由到对应的数字员工Agent
    """
    category = state.intent_category
    if category == "行政":
        return "行政助手"
    elif category == "人事":
        return "人事助手"
    elif category == "财务":
        return "财务助手"
    elif category == "业务":
        return "业务助手"
    else:
        return "行政助手"


# 创建状态图
builder = StateGraph(GlobalState, input_schema=GraphInput, output_schema=GraphOutput)

# 添加节点
builder.add_node("intent_recognition", intent_recognition_node,
                 metadata={"type": "agent", "llm_cfg": "config/intent_recognition_llm_cfg.json"})

builder.add_node("knowledge_retrieval", knowledge_retrieval_node)

builder.add_node("admin_assistant", admin_assistant_node,
                 metadata={"type": "agent", "llm_cfg": "config/admin_assistant_llm_cfg.json"})

builder.add_node("hr_assistant", hr_assistant_node,
                 metadata={"type": "agent", "llm_cfg": "config/hr_assistant_llm_cfg.json"})

builder.add_node("finance_assistant", finance_assistant_node,
                 metadata={"type": "agent", "llm_cfg": "config/finance_assistant_llm_cfg.json"})

builder.add_node("business_assistant", business_assistant_node,
                 metadata={"type": "agent", "llm_cfg": "config/business_assistant_llm_cfg.json"})

builder.add_node("result_summary", result_summary_node,
                 metadata={"type": "agent", "llm_cfg": "config/result_summary_llm_cfg.json"})

# 设置入口点
builder.set_entry_point("intent_recognition")

# 意图识别 -> 知识库检索（并行获取知识增强）
builder.add_edge("intent_recognition", "knowledge_retrieval")

# 知识库检索 -> 条件路由分发
builder.add_conditional_edges(
    source="knowledge_retrieval",
    path=route_dispatch_func,
    path_map={
        "行政助手": "admin_assistant",
        "人事助手": "hr_assistant",
        "财务助手": "finance_assistant",
        "业务助手": "business_assistant"
    }
)

# 各Agent -> 结果汇总
builder.add_edge("admin_assistant", "result_summary")
builder.add_edge("hr_assistant", "result_summary")
builder.add_edge("finance_assistant", "result_summary")
builder.add_edge("business_assistant", "result_summary")

# 结果汇总 -> 结束
builder.add_edge("result_summary", END)

# 编译图
main_graph = builder.compile()
