# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
企业智能运营多智能体协作系统 - 状态定义
包含全局状态、图出入参、各节点独立出入参
"""
from typing import Optional, List
from pydantic import BaseModel, Field


# ==================== 全局状态 ====================

class GlobalState(BaseModel):
    """全局状态定义 - 工作流全生命周期数据"""
    user_requirement: str = Field(default="", description="用户原始需求")
    task_plan: str = Field(default="", description="Manager Agent拆解的任务计划")
    market_result: str = Field(default="", description="市场分析Agent的输出结果")
    content_result: str = Field(default="", description="内容创作Agent的输出结果")
    data_result: str = Field(default="", description="数据分析Agent的输出结果")
    service_result: str = Field(default="", description="客服运营Agent的输出结果")
    knowledge_context: str = Field(default="", description="知识库检索到的相关企业信息")
    merged_results: str = Field(default="", description="各Agent结果汇总与通信交换信息")
    final_report: str = Field(default="", description="综合决策Agent生成的最终运营报告")


# ==================== 图出入参 ====================

class GraphInput(BaseModel):
    """工作流输入"""
    user_requirement: str = Field(..., description="用户输入的运营需求，如市场分析、内容策划、数据报告等")


class GraphOutput(BaseModel):
    """工作流输出"""
    final_report: str = Field(..., description="综合决策Agent生成的最终运营报告")
    market_result: str = Field(default="", description="市场分析结果")
    content_result: str = Field(default="", description="内容创作结果")
    data_result: str = Field(default="", description="数据分析结果")
    service_result: str = Field(default="", description="客服运营分析结果")


# ==================== 节点独立出入参 ====================

# --- Manager Agent ---
class ManagerAgentInput(BaseModel):
    """Manager Agent 节点输入"""
    user_requirement: str = Field(..., description="用户原始运营需求")


class ManagerAgentOutput(BaseModel):
    """Manager Agent 节点输出"""
    task_plan: str = Field(..., description="拆解后的任务计划，包含各Agent的任务分配说明")


# --- 市场分析 Agent ---
class MarketAnalysisInput(BaseModel):
    """市场分析Agent节点输入"""
    user_requirement: str = Field(..., description="用户原始需求")
    task_plan: str = Field(..., description="Manager分配的市场分析任务说明")


class MarketAnalysisOutput(BaseModel):
    """市场分析Agent节点输出"""
    market_result: str = Field(..., description="市场分析结果，包含竞品分析、用户画像、趋势预测等")


# --- 内容创作 Agent ---
class ContentCreationInput(BaseModel):
    """内容创作Agent节点输入"""
    user_requirement: str = Field(..., description="用户原始需求")
    task_plan: str = Field(..., description="Manager分配的内容创作任务说明")


class ContentCreationOutput(BaseModel):
    """内容创作Agent节点输出"""
    content_result: str = Field(..., description="内容创作结果，包含文案方案、海报设计建议等")


# --- 数据分析 Agent ---
class DataAnalysisInput(BaseModel):
    """数据分析Agent节点输入"""
    user_requirement: str = Field(..., description="用户原始需求")
    task_plan: str = Field(..., description="Manager分配的数据分析任务说明")


class DataAnalysisOutput(BaseModel):
    """数据分析Agent节点输出"""
    data_result: str = Field(..., description="数据分析结果，包含统计结果、分析报告等")


# --- 客服运营 Agent ---
class CustomerServiceInput(BaseModel):
    """客服运营Agent节点输入"""
    user_requirement: str = Field(..., description="用户原始需求")
    task_plan: str = Field(..., description="Manager分配的客服运营任务说明")


class CustomerServiceOutput(BaseModel):
    """客服运营Agent节点输出"""
    service_result: str = Field(..., description="客服运营分析结果，包含反馈分析、问题分类、服务建议等")


# --- 知识库检索节点 ---
class KnowledgeRetrievalInput(BaseModel):
    """知识库检索节点输入"""
    user_requirement: str = Field(..., description="用户原始需求")
    market_result: str = Field(..., description="市场分析结果")
    content_result: str = Field(..., description="内容创作结果")
    data_result: str = Field(..., description="数据分析结果")
    service_result: str = Field(..., description="客服运营分析结果")


class KnowledgeRetrievalOutput(BaseModel):
    """知识库检索节点输出"""
    knowledge_context: str = Field(..., description="从知识库检索到的企业资料、产品信息、行业知识")
    merged_results: str = Field(..., description="各Agent结果汇总，包含Agent间通信交换的信息")


# --- 综合决策 Agent ---
class ComprehensiveDecisionInput(BaseModel):
    """综合决策Agent节点输入"""
    user_requirement: str = Field(..., description="用户原始需求")
    merged_results: str = Field(..., description="各Agent结果汇总信息")
    knowledge_context: str = Field(..., description="知识库提供的企业/行业知识")


class ComprehensiveDecisionOutput(BaseModel):
    """综合决策Agent节点输出"""
    final_report: str = Field(..., description="综合决策报告，包含执行方案、运营建议等")
