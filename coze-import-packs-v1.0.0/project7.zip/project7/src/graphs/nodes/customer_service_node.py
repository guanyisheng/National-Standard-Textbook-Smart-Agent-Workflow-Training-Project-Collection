# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
客服运营Agent节点
负责：用户反馈分析、问题分类、服务建议
"""
import os
import json
from jinja2 import Template
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from graphs.state import CustomerServiceInput, CustomerServiceOutput


def _extract_text(content) -> str:
    """安全提取LLM返回的文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            return " ".join(
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            )
    return str(content)


def customer_service_node(
    state: CustomerServiceInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> CustomerServiceOutput:
    """
    title: 客服运营Agent
    desc: 分析用户反馈、对问题进行分类和优先级排序，提供客服服务优化建议
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 读取LLM配置
    cfg_path = os.path.join(
        os.getenv("COZE_WORKSPACE_PATH", ""),
        config["metadata"]["llm_cfg"]
    )
    with open(cfg_path, "r", encoding="utf-8") as f:
        llm_cfg = json.load(f)

    llm_config = llm_cfg.get("config", {})
    sp = llm_cfg.get("sp", "")
    up_tpl_str = llm_cfg.get("up", "")

    # 渲染用户提示词模板
    up_tpl = Template(up_tpl_str)
    user_prompt = up_tpl.render(
        user_requirement=state.user_requirement,
        task_plan=state.task_plan
    )

    # 调用LLM
    client = LLMClient(ctx=ctx)
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=user_prompt)
    ]

    response = client.invoke(
        messages=messages,
        model=llm_config.get("model", "doubao-seed-2-0-lite-260215"),
        temperature=llm_config.get("temperature", 0.4),
        top_p=llm_config.get("top_p", 0.9),
        max_completion_tokens=llm_config.get("max_completion_tokens", 2000)
    )

    service_result = _extract_text(response.content)

    return CustomerServiceOutput(service_result=service_result)
