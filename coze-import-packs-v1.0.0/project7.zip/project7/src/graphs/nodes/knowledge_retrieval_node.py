# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
知识库检索与Agent通信协作节点
负责：从知识库检索企业资料/产品信息/行业知识，汇总各Agent结果并实现Agent间信息共享
"""
import os
import logging
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import KnowledgeClient, Config as KnowledgeConfig
from graphs.state import KnowledgeRetrievalInput, KnowledgeRetrievalOutput

logger = logging.getLogger(__name__)


def knowledge_retrieval_node(
    state: KnowledgeRetrievalInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> KnowledgeRetrievalOutput:
    """
    title: Agent通信协作与知识增强
    desc: 汇总各Agent分析结果实现信息共享与任务传递，同时从知识库检索企业资料、产品数据和行业知识进行增强
    """
    ctx = runtime.context

    # 1. 构建各Agent结果汇总（Agent通信协作层 - 信息共享与结果交换）
    merged_parts = [
        f"=== 市场分析Agent输出 ===\n{state.market_result}",
        f"=== 内容创作Agent输出 ===\n{state.content_result}",
        f"=== 数据分析Agent输出 ===\n{state.data_result}",
        f"=== 客服运营Agent输出 ===\n{state.service_result}",
    ]
    merged_results = "\n\n".join(merged_parts)

    # 2. 知识库检索（知识增强）
    knowledge_context = ""
    try:
        knowledge_client = KnowledgeClient(config=KnowledgeConfig(), ctx=ctx)

        # 根据用户需求进行多维度知识检索
        search_queries = [
            state.user_requirement,
            "企业运营策略 产品方案",
            "行业趋势 市场分析"
        ]

        knowledge_parts = []
        for query in search_queries:
            try:
                search_response = knowledge_client.search(
                    query=query,
                    top_k=3,
                    min_score=0.3
                )
                if search_response.code == 0 and search_response.chunks:
                    for chunk in search_response.chunks:
                        chunk_text = chunk.content if hasattr(chunk, "content") else str(chunk)
                        knowledge_parts.append(chunk_text)
            except Exception as e:
                logger.warning(f"Knowledge search failed for query '{query}': {e}")
                continue

        if knowledge_parts:
            knowledge_context = "\n---\n".join(knowledge_parts)
        else:
            knowledge_context = "知识库中暂无与当前需求直接相关的资料，请基于各Agent分析结果进行决策。"

    except Exception as e:
        logger.error(f"Knowledge retrieval failed: {e}")
        knowledge_context = "知识库服务暂时不可用，请基于各Agent分析结果进行决策。"

    return KnowledgeRetrievalOutput(
        knowledge_context=knowledge_context,
        merged_results=merged_results
    )
