# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
企业智能运营多智能体协作系统 - 主图编排
流程：用户需求 → Manager Agent → 并行4个专业Agent → 知识增强与通信协作 → 综合决策 → 输出报告
"""
from langgraph.graph import StateGraph, END
from graphs.state import (
    GlobalState,
    GraphInput,
    GraphOutput,
)

# 导入所有节点函数
from graphs.nodes.manager_agent_node import manager_agent_node
from graphs.nodes.market_analysis_node import market_analysis_node
from graphs.nodes.content_creation_node import content_creation_node
from graphs.nodes.data_analysis_node import data_analysis_node
from graphs.nodes.customer_service_node import customer_service_node
from graphs.nodes.knowledge_retrieval_node import knowledge_retrieval_node
from graphs.nodes.comprehensive_decision_node import comprehensive_decision_node

# 创建状态图，指定全局状态、入参和出参
builder = StateGraph(GlobalState, input_schema=GraphInput, output_schema=GraphOutput)

# ==================== 添加节点 ====================

# Manager Agent - 智能体管理中心（Agent节点）
builder.add_node(
    "manager_agent",
    manager_agent_node,
    metadata={"type": "agent", "llm_cfg": "config/manager_agent_llm_cfg.json"}
)

# 市场分析Agent（Agent节点）
builder.add_node(
    "market_analysis",
    market_analysis_node,
    metadata={"type": "agent", "llm_cfg": "config/market_analysis_llm_cfg.json"}
)

# 内容创作Agent（Agent节点）
builder.add_node(
    "content_creation",
    content_creation_node,
    metadata={"type": "agent", "llm_cfg": "config/content_creation_llm_cfg.json"}
)

# 数据分析Agent（Agent节点）
builder.add_node(
    "data_analysis",
    data_analysis_node,
    metadata={"type": "agent", "llm_cfg": "config/data_analysis_llm_cfg.json"}
)

# 客服运营Agent（Agent节点）
builder.add_node(
    "customer_service",
    customer_service_node,
    metadata={"type": "agent", "llm_cfg": "config/customer_service_llm_cfg.json"}
)

# Agent通信协作与知识增强节点（任务节点）
builder.add_node(
    "knowledge_retrieval",
    knowledge_retrieval_node
)

# 综合决策Agent（Agent节点）
builder.add_node(
    "comprehensive_decision",
    comprehensive_decision_node,
    metadata={"type": "agent", "llm_cfg": "config/comprehensive_decision_llm_cfg.json"}
)

# ==================== 设置边 ====================

# 入口：Manager Agent
builder.set_entry_point("manager_agent")

# Manager Agent → 并行分发到4个专业Agent
builder.add_edge("manager_agent", "market_analysis")
builder.add_edge("manager_agent", "content_creation")
builder.add_edge("manager_agent", "data_analysis")
builder.add_edge("manager_agent", "customer_service")

# 4个专业Agent → 汇聚到知识增强与通信协作节点
builder.add_edge(
    ["market_analysis", "content_creation", "data_analysis", "customer_service"],
    "knowledge_retrieval"
)

# 知识增强 → 综合决策
builder.add_edge("knowledge_retrieval", "comprehensive_decision")

# 综合决策 → 结束
builder.add_edge("comprehensive_decision", END)

# 编译图
main_graph = builder.compile()
