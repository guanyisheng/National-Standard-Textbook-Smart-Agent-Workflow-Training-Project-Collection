## 项目概述
- **名称**: 企业智能运营多智能体协作系统
- **功能**: 基于多Agent协作的企业运营决策系统，通过Manager Agent拆解任务，并行调用市场分析、内容创作、数据分析、客服运营四个专业智能体，结合知识库增强，最终由综合决策Agent生成运营报告

### 节点清单
| 节点名 | 文件位置 | 类型 | 功能描述 | 分支逻辑 | 配置文件 |
|-------|---------|------|---------|---------|---------|
| manager_agent | `nodes/manager_agent_node.py` | agent | 智能体管理中心：需求理解、任务拆解、Agent调度 | - | `config/manager_agent_llm_cfg.json` |
| market_analysis | `nodes/market_analysis_node.py` | agent | 市场分析：竞品分析、用户画像、趋势预测 | - | `config/market_analysis_llm_cfg.json` |
| content_creation | `nodes/content_creation_node.py` | agent | 内容创作：文案生成、海报设计、内容优化 | - | `config/content_creation_llm_cfg.json` |
| data_analysis | `nodes/data_analysis_node.py` | agent | 数据分析：数据整理、统计分析、可视化报告 | - | `config/data_analysis_llm_cfg.json` |
| customer_service | `nodes/customer_service_node.py` | agent | 客服运营：反馈分析、问题分类、服务建议 | - | `config/customer_service_llm_cfg.json` |
| knowledge_retrieval | `nodes/knowledge_retrieval_node.py` | task | Agent通信协作与知识增强：汇总结果、知识库检索 | - | - |
| comprehensive_decision | `nodes/comprehensive_decision_node.py` | agent | 综合决策：汇总分析、生成方案、输出报告 | - | `config/comprehensive_decision_llm_cfg.json` |

**类型说明**: task(task节点) / agent(大模型) / condition(条件分支) / looparray(列表循环) / loopcond(条件循环)

## 工作流拓扑
```
用户输入 → manager_agent → [market_analysis || content_creation || data_analysis || customer_service] → knowledge_retrieval → comprehensive_decision → 输出
```

## 子图清单
无

## 技能使用
- 节点 `manager_agent`、`market_analysis`、`content_creation`、`data_analysis`、`customer_service`、`comprehensive_decision` 使用大语言模型技能（LLM）
- 节点 `knowledge_retrieval` 使用知识库技能（Knowledge Base）
