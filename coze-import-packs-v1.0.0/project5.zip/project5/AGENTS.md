## 项目概述
- **名称**: 企业知识库增强RAG数智员工智能体
- **功能**: 基于企业知识库的RAG智能问答系统，支持意图识别、语义检索、知识融合与智能审核

### 节点清单
| 节点名 | 文件位置 | 类型 | 功能描述 | 分支逻辑 | 配置文件 |
|-------|---------|------|---------|---------|---------|
| intent_recognition | `nodes/intent_recognition_node.py` | agent | 用户意图识别：问题分类、关键词提取、业务场景判断 | - | `config/intent_recognition_llm_cfg.json` |
| knowledge_search | `nodes/knowledge_search_node.py` | task | 知识库语义检索：基于问题和关键词进行向量搜索 | - | - |
| policy_query | `nodes/policy_query_node.py` | task | 企业制度查询：过滤制度相关检索结果 | 条件分支"企业制度查询" | - |
| product_query | `nodes/product_query_node.py` | task | 产品知识查询：过滤产品相关检索结果 | 条件分支"产品知识查询" | - |
| process_query | `nodes/process_query_node.py` | task | 业务流程查询：过滤流程相关检索结果 | 条件分支"业务流程查询" | - |
| knowledge_fusion | `nodes/knowledge_fusion_node.py` | agent | 知识融合生成：整合检索结果生成答案 | - | `config/knowledge_fusion_llm_cfg.json` |
| review | `nodes/review_node.py` | agent | 智能审核：准确性检查与内容安全审核 | - | `config/review_llm_cfg.json` |
| output_format | `nodes/output_format_node.py` | task | 输出格式化：确定输出类型，整理参考文献 | - | - |

**类型说明**: task(task节点) / agent(大模型) / condition(条件分支) / looparray(列表循环) / loopcond(条件循环)

### 条件分支
| 路由函数 | 源节点 | 分支 | 目标节点 |
|---------|-------|------|---------|
| search_decision_path | knowledge_search | 企业制度查询 | policy_query |
| search_decision_path | knowledge_search | 产品知识查询 | product_query |
| search_decision_path | knowledge_search | 业务流程查询 | process_query |

## 技能使用
- 节点 `intent_recognition` 使用技能：大语言模型 (doubao-seed-2-0-mini-260215)
- 节点 `knowledge_search` 使用技能：知识库 (KnowledgeClient)
- 节点 `knowledge_fusion` 使用技能：大语言模型 (doubao-seed-2-0-lite-260215)
- 节点 `review` 使用技能：大语言模型 (doubao-seed-2-0-pro-260215)
