# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
企业知识库增强RAG数智员工智能体 - 状态定义
"""
from typing import List, Optional, Dict
from pydantic import BaseModel, Field


# ============================================================
# 全局状态定义
# ============================================================

class GlobalState(BaseModel):
    """全局状态：工作流运行过程中的所有数据"""
    # 用户输入
    user_question: str = Field(default="", description="用户提出的问题")

    # 意图识别结果
    intent_category: str = Field(default="", description="问题分类：企业制度/产品知识/业务流程")
    keywords: List[str] = Field(default=[], description="提取的关键词列表")
    scenario: str = Field(default="", description="业务场景描述")

    # 知识库检索结果
    search_results: List[Dict] = Field(default=[], description="知识库语义检索原始结果")
    result_count: int = Field(default=0, description="检索结果数量")

    # 分支查询结果
    filtered_results: List[Dict] = Field(default=[], description="过滤后的检索结果")
    query_context: str = Field(default="", description="查询上下文信息")

    # 知识融合结果
    generated_answer: str = Field(default="", description="LLM生成的答案")
    sources: List[str] = Field(default=[], description="引用来源列表")

    # 审核结果
    reviewed_answer: str = Field(default="", description="审核后的答案")
    accuracy_score: float = Field(default=0.0, description="准确性评分 0-1")
    is_safe: bool = Field(default=True, description="内容是否安全合规")
    audit_notes: str = Field(default="", description="审核备注")

    # 最终输出
    final_answer: str = Field(default="", description="最终输出答案")
    output_type: str = Field(default="", description="输出类型：智能问答/文档生成/工单创建")
    references: List[str] = Field(default=[], description="参考文献列表")


# ============================================================
# 图输入输出定义
# ============================================================

class GraphInput(BaseModel):
    """工作流输入"""
    user_question: str = Field(..., description="用户提出的问题")


class GraphOutput(BaseModel):
    """工作流输出"""
    final_answer: str = Field(..., description="最终回答内容")
    output_type: str = Field(default="智能问答", description="输出类型：智能问答/文档生成/工单创建")
    intent_category: str = Field(default="", description="问题分类")
    accuracy_score: float = Field(default=0.0, description="准确性评分")
    references: List[str] = Field(default=[], description="引用来源")


# ============================================================
# 节点输入输出定义
# ============================================================

# --- 意图识别节点 ---
class IntentRecognitionInput(BaseModel):
    """意图识别节点输入"""
    user_question: str = Field(..., description="用户提出的问题")


class IntentRecognitionOutput(BaseModel):
    """意图识别节点输出"""
    intent_category: str = Field(..., description="问题分类：企业制度/产品知识/业务流程")
    keywords: List[str] = Field(default=[], description="提取的关键词列表")
    scenario: str = Field(default="", description="业务场景描述")


# --- 知识库检索节点 ---
class KnowledgeSearchInput(BaseModel):
    """知识库检索节点输入"""
    user_question: str = Field(..., description="用户提出的问题")
    keywords: List[str] = Field(default=[], description="提取的关键词列表")


class KnowledgeSearchOutput(BaseModel):
    """知识库检索节点输出"""
    search_results: List[Dict] = Field(default=[], description="知识库检索结果列表")
    result_count: int = Field(default=0, description="检索结果数量")


# --- 检索决策路由 ---
class SearchDecisionInput(BaseModel):
    """检索决策路由输入"""
    intent_category: str = Field(..., description="问题分类：企业制度/产品知识/业务流程")


# --- 企业制度查询节点 ---
class PolicyQueryInput(BaseModel):
    """企业制度查询节点输入"""
    search_results: List[Dict] = Field(default=[], description="知识库检索结果")
    intent_category: str = Field(default="", description="问题分类")
    keywords: List[str] = Field(default=[], description="关键词列表")


class PolicyQueryOutput(BaseModel):
    """企业制度查询节点输出"""
    filtered_results: List[Dict] = Field(default=[], description="过滤后的制度相关结果")
    query_context: str = Field(default="", description="制度查询上下文")


# --- 产品知识查询节点 ---
class ProductQueryInput(BaseModel):
    """产品知识查询节点输入"""
    search_results: List[Dict] = Field(default=[], description="知识库检索结果")
    intent_category: str = Field(default="", description="问题分类")
    keywords: List[str] = Field(default=[], description="关键词列表")


class ProductQueryOutput(BaseModel):
    """产品知识查询节点输出"""
    filtered_results: List[Dict] = Field(default=[], description="过滤后的产品知识结果")
    query_context: str = Field(default="", description="产品查询上下文")


# --- 业务流程查询节点 ---
class ProcessQueryInput(BaseModel):
    """业务流程查询节点输入"""
    search_results: List[Dict] = Field(default=[], description="知识库检索结果")
    intent_category: str = Field(default="", description="问题分类")
    keywords: List[str] = Field(default=[], description="关键词列表")


class ProcessQueryOutput(BaseModel):
    """业务流程查询节点输出"""
    filtered_results: List[Dict] = Field(default=[], description="过滤后的流程相关结果")
    query_context: str = Field(default="", description="流程查询上下文")


# --- 知识融合生成节点 ---
class KnowledgeFusionInput(BaseModel):
    """知识融合生成节点输入"""
    user_question: str = Field(..., description="用户原始问题")
    query_context: str = Field(default="", description="查询上下文")
    filtered_results: List[Dict] = Field(default=[], description="过滤后的检索结果")
    intent_category: str = Field(default="", description="问题分类")


class KnowledgeFusionOutput(BaseModel):
    """知识融合生成节点输出"""
    generated_answer: str = Field(..., description="生成的答案")
    sources: List[str] = Field(default=[], description="引用来源列表")


# --- 智能审核节点 ---
class ReviewInput(BaseModel):
    """智能审核节点输入"""
    generated_answer: str = Field(..., description="生成的答案")
    user_question: str = Field(..., description="用户原始问题")
    sources: List[str] = Field(default=[], description="引用来源列表")


class ReviewOutput(BaseModel):
    """智能审核节点输出"""
    reviewed_answer: str = Field(..., description="审核后的答案")
    accuracy_score: float = Field(default=0.0, description="准确性评分 0-1")
    is_safe: bool = Field(default=True, description="内容是否安全合规")
    audit_notes: str = Field(default="", description="审核备注")


# --- 输出格式化节点 ---
class OutputFormatInput(BaseModel):
    """输出格式化节点输入"""
    reviewed_answer: str = Field(..., description="审核后的答案")
    accuracy_score: float = Field(default=0.0, description="准确性评分")
    is_safe: bool = Field(default=True, description="内容是否安全")
    audit_notes: str = Field(default="", description="审核备注")
    intent_category: str = Field(default="", description="问题分类")
    sources: List[str] = Field(default=[], description="引用来源")


class OutputFormatOutput(BaseModel):
    """输出格式化节点输出"""
    final_answer: str = Field(..., description="最终输出答案")
    output_type: str = Field(default="智能问答", description="输出类型")
    references: List[str] = Field(default=[], description="参考文献列表")
