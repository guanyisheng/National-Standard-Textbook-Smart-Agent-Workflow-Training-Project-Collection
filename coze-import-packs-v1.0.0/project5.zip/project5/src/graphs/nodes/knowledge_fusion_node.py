# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
知识融合生成节点 - 使用LLM整合检索结果生成答案
"""
import os
import json
from typing import List, Dict
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from graphs.state import KnowledgeFusionInput, KnowledgeFusionOutput


def _extract_text_content(content) -> str:
    """安全提取LLM返回的文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            return " ".join(
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            )
    return str(content)


def knowledge_fusion_node(
    state: KnowledgeFusionInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> KnowledgeFusionOutput:
    """
    title: 知识融合生成
    desc: 基于知识库检索结果，整合多源信息并使用LLM生成结构化答案，标注引用来源
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 读取LLM配置
    cfg_file = os.path.join(
        os.getenv("COZE_WORKSPACE_PATH", ""),
        config["metadata"]["llm_cfg"]
    )
    with open(cfg_file, "r") as fd:
        llm_cfg = json.load(fd)

    llm_config: Dict = llm_cfg.get("config", {})
    sp: str = llm_cfg.get("sp", "")
    up_tpl_str: str = llm_cfg.get("up", "")

    # 渲染用户提示词模板
    up_tpl = Template(up_tpl_str)
    user_prompt: str = up_tpl.render(
        user_question=state.user_question,
        intent_category=state.intent_category,
        query_context=state.query_context,
        filtered_results=state.filtered_results
    )

    # 调用LLM
    client = LLMClient(ctx=ctx)
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=user_prompt)
    ]

    model_id: str = llm_config.get("model", "doubao-seed-2-0-lite-260215")
    temperature: float = float(llm_config.get("temperature", 0.3))
    max_tokens: int = int(llm_config.get("max_completion_tokens", 4000))

    response = client.invoke(
        messages=messages,
        model=model_id,
        temperature=temperature,
        max_completion_tokens=max_tokens
    )

    # 解析LLM返回
    raw_text: str = _extract_text_content(response.content)

    generated_answer: str = ""
    sources: List[str] = []

    try:
        json_start = raw_text.find("{")
        json_end = raw_text.rfind("}") + 1
        if json_start >= 0 and json_end > json_start:
            json_str = raw_text[json_start:json_end]
            parsed = json.loads(json_str)
            generated_answer = parsed.get("generated_answer", "")
            sources = parsed.get("sources", [])
    except (json.JSONDecodeError, ValueError):
        # 如果JSON解析失败，将原始文本作为答案
        generated_answer = raw_text
        sources = []

    # 兜底：如果答案为空
    if not generated_answer:
        generated_answer = "抱歉，基于当前知识库内容暂时无法回答您的问题，建议补充相关知识文档或联系人工客服。"

    return KnowledgeFusionOutput(
        generated_answer=generated_answer,
        sources=sources
    )
