# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
智能审核节点 - 使用LLM进行准确性检查与内容安全审核
"""
import os
import json
from typing import List, Dict
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from graphs.state import ReviewInput, ReviewOutput


def _extract_text_content(content) -> str:
    """安全提取LLM返回的文本内容"""
    if isinstance(content, str):
        return content
    elif isinstance(content, list):
        if content and isinstance(content[0], str):
            return " ".join(content)
        else:
            return " ".join(
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type") == "text"
            )
    return str(content)


def review_node(
    state: ReviewInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ReviewOutput:
    """
    title: 智能审核
    desc: 对生成的答案进行准确性验证和内容安全检查，确保回答质量与合规性
    integrations: 大语言模型
    """
    ctx = runtime.context

    # 读取LLM配置
    cfg_file = os.path.join(
        os.getenv("COZE_WORKSPACE_PATH", ""),
        config["metadata"]["llm_cfg"]
    )
    with open(cfg_file, "r") as fd:
        llm_cfg = json.load(fd)

    llm_config: Dict = llm_cfg.get("config", {})
    sp: str = llm_cfg.get("sp", "")
    up_tpl_str: str = llm_cfg.get("up", "")

    # 渲染用户提示词模板
    up_tpl = Template(up_tpl_str)
    user_prompt: str = up_tpl.render(
        user_question=state.user_question,
        generated_answer=state.generated_answer,
        sources=state.sources
    )

    # 调用LLM
    client = LLMClient(ctx=ctx)
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=user_prompt)
    ]

    model_id: str = llm_config.get("model", "doubao-seed-2-0-pro-260215")
    temperature: float = float(llm_config.get("temperature", 0.1))
    max_tokens: int = int(llm_config.get("max_completion_tokens", 3000))

    response = client.invoke(
        messages=messages,
        model=model_id,
        temperature=temperature,
        max_completion_tokens=max_tokens
    )

    # 解析LLM返回
    raw_text: str = _extract_text_content(response.content)

    reviewed_answer: str = state.generated_answer
    accuracy_score: float = 0.8
    is_safe: bool = True
    audit_notes: str = ""

    try:
        json_start = raw_text.find("{")
        json_end = raw_text.rfind("}") + 1
        if json_start >= 0 and json_end > json_start:
            json_str = raw_text[json_start:json_end]
            parsed = json.loads(json_str)
            reviewed_answer = parsed.get("reviewed_answer", state.generated_answer)
            accuracy_score = float(parsed.get("accuracy_score", 0.8))
            is_safe = bool(parsed.get("is_safe", True))
            audit_notes = str(parsed.get("audit_notes", ""))
    except (json.JSONDecodeError, ValueError):
        reviewed_answer = state.generated_answer
        audit_notes = "审核结果解析异常，保留原始答案"

    return ReviewOutput(
        reviewed_answer=reviewed_answer,
        accuracy_score=accuracy_score,
        is_safe=is_safe,
        audit_notes=audit_notes
    )
