# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
产品知识查询节点 - 过滤和增强产品知识相关的检索结果
"""
import logging
from typing import List, Dict
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import ProductQueryInput, ProductQueryOutput

logger = logging.getLogger(__name__)

# 产品相关的关键词
PRODUCT_KEYWORDS: List[str] = [
    "产品", "功能", "参数", "规格", "型号", "配置", "版本",
    "使用", "操作", "说明", "技术", "特性", "优势", "对比",
    "故障", "问题", "解决", "维修", "安装", "部署", "接口"
]


def product_query_node(
    state: ProductQueryInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ProductQueryOutput:
    """
    title: 产品知识查询
    desc: 根据产品相关关键词过滤知识库检索结果，提取与产品参数、功能说明、使用方法相关的内容
    """
    search_results: List[Dict] = state.search_results
    keywords: List[str] = state.keywords

    # 过滤产品相关的检索结果
    filtered: List[Dict] = []
    for item in search_results:
        content: str = item.get("content", "")
        score: float = float(item.get("score", 0.0))

        # 检查内容是否包含产品相关关键词
        is_product_related: bool = any(
            kw in content for kw in PRODUCT_KEYWORDS
        )
        # 或者用户关键词在内容中出现
        has_user_keyword: bool = any(
            kw in content for kw in keywords
        ) if keywords else True

        if (is_product_related or has_user_keyword) and score >= 0.3:
            filtered.append(item)

    # 如果没有过滤到结果，保留原始高分结果
    if not filtered and search_results:
        filtered = [
            item for item in search_results
            if float(item.get("score", 0.0)) >= 0.5
        ][:5]

    # 构建查询上下文
    context_parts: List[str] = []
    if keywords:
        context_parts.append(f"查询关键词: {', '.join(keywords)}")
    context_parts.append(f"匹配到 {len(filtered)} 条产品知识内容")

    query_context: str = "; ".join(context_parts)
    logger.info(f"产品知识查询完成，过滤出 {len(filtered)} 条结果")

    return ProductQueryOutput(
        filtered_results=filtered,
        query_context=query_context
    )
