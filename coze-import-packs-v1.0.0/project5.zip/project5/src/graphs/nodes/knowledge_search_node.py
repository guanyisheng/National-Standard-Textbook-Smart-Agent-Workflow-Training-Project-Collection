# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
知识库检索节点 - 使用Knowledge SDK进行语义搜索
"""
import os
import logging
from typing import List, Dict
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import KnowledgeClient, Config
from graphs.state import KnowledgeSearchInput, KnowledgeSearchOutput

logger = logging.getLogger(__name__)


def knowledge_search_node(
    state: KnowledgeSearchInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> KnowledgeSearchOutput:
    """
    title: 知识库语义检索
    desc: 基于用户问题和提取的关键词，在企业知识库中进行语义搜索，返回相关知识片段
    integrations: 知识库
    """
    ctx = runtime.context

    # 构建查询文本：将用户问题和关键词组合
    query_text: str = state.user_question
    if state.keywords:
        keywords_str: str = " ".join(state.keywords)
        query_text = f"{state.user_question} {keywords_str}"

    # 初始化知识库客户端
    sdk_config = Config()
    client = KnowledgeClient(config=sdk_config, ctx=ctx)

    # 执行语义搜索
    search_results: List[Dict] = []
    result_count: int = 0

    try:
        response = client.search(
            query=query_text,
            top_k=10,
            min_score=0.3
        )

        if response.code == 0 and response.chunks:
            for chunk in response.chunks:
                search_results.append({
                    "content": chunk.content,
                    "score": float(chunk.score) if chunk.score is not None else 0.0,
                    "doc_id": getattr(chunk, "doc_id", "")
                })
            result_count = len(search_results)
            logger.info(f"知识库检索成功，返回 {result_count} 条结果")
        else:
            error_msg: str = getattr(response, "msg", "未知错误")
            logger.warning(f"知识库检索返回异常: {error_msg}")
    except Exception as e:
        logger.error(f"知识库检索异常: {str(e)}")
        search_results = []
        result_count = 0

    return KnowledgeSearchOutput(
        search_results=search_results,
        result_count=result_count
    )
