# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
业务流程查询节点 - 过滤和增强业务流程相关的检索结果
"""
import logging
from typing import List, Dict
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import ProcessQueryInput, ProcessQueryOutput

logger = logging.getLogger(__name__)

# 流程相关的关键词
PROCESS_KEYWORDS: List[str] = [
    "流程", "步骤", "办理", "申请", "审批", "提交", "审核",
    "操作", "指南", "指导", "程序", "环节", "阶段", "顺序",
    "条件", "材料", "资料", "表格", "表单", "时限", "期限"
]


def process_query_node(
    state: ProcessQueryInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ProcessQueryOutput:
    """
    title: 业务流程查询
    desc: 根据流程相关关键词过滤知识库检索结果，提取与业务流程、办理步骤、操作指南相关的内容
    """
    search_results: List[Dict] = state.search_results
    keywords: List[str] = state.keywords

    # 过滤流程相关的检索结果
    filtered: List[Dict] = []
    for item in search_results:
        content: str = item.get("content", "")
        score: float = float(item.get("score", 0.0))

        # 检查内容是否包含流程相关关键词
        is_process_related: bool = any(
            kw in content for kw in PROCESS_KEYWORDS
        )
        # 或者用户关键词在内容中出现
        has_user_keyword: bool = any(
            kw in content for kw in keywords
        ) if keywords else True

        if (is_process_related or has_user_keyword) and score >= 0.3:
            filtered.append(item)

    # 如果没有过滤到结果，保留原始高分结果
    if not filtered and search_results:
        filtered = [
            item for item in search_results
            if float(item.get("score", 0.0)) >= 0.5
        ][:5]

    # 构建查询上下文
    context_parts: List[str] = []
    if keywords:
        context_parts.append(f"查询关键词: {', '.join(keywords)}")
    context_parts.append(f"匹配到 {len(filtered)} 条流程相关内容")

    query_context: str = "; ".join(context_parts)
    logger.info(f"业务流程查询完成，过滤出 {len(filtered)} 条结果")

    return ProcessQueryOutput(
        filtered_results=filtered,
        query_context=query_context
    )
