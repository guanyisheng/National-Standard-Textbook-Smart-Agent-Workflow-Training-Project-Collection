# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
输出格式化节点 - 根据审核结果和意图分类格式化最终输出
"""
import logging
from typing import List
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import OutputFormatInput, OutputFormatOutput

logger = logging.getLogger(__name__)


def output_format_node(
    state: OutputFormatInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> OutputFormatOutput:
    """
    title: 输出格式化
    desc: 根据审核结果确定输出类型，格式化最终答案并整理参考文献列表
    """
    reviewed_answer: str = state.reviewed_answer
    accuracy_score: float = state.accuracy_score
    is_safe: bool = state.is_safe
    audit_notes: str = state.audit_notes
    intent_category: str = state.intent_category
    sources: List[str] = state.sources

    # 确定输出类型
    output_type: str = "智能问答"
    if not is_safe:
        output_type = "安全拦截"
        reviewed_answer = "抱歉，该回答内容未通过安全审核，暂时无法提供。请联系人工客服获取帮助。"
    elif accuracy_score < 0.5:
        output_type = "低置信度问答"
        reviewed_answer = f"以下回答置信度较低，仅供参考：\n\n{reviewed_answer}"
    elif intent_category == "业务流程":
        # 流程类问题可能涉及工单创建
        if "申请" in reviewed_answer or "办理" in reviewed_answer:
            output_type = "工单创建"

    # 整理参考文献
    references: List[str] = []
    for i, source in enumerate(sources):
        if source and isinstance(source, str):
            ref: str = source.strip()
            if ref:
                references.append(f"[{i + 1}] {ref}")

    # 添加审核备注（如果有）
    if audit_notes and is_safe:
        logger.info(f"审核备注: {audit_notes}")

    final_answer: str = reviewed_answer

    logger.info(f"输出格式化完成，类型: {output_type}, 引用数: {len(references)}")

    return OutputFormatOutput(
        final_answer=final_answer,
        output_type=output_type,
        references=references
    )
