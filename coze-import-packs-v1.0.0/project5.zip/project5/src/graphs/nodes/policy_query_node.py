# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
企业制度查询节点 - 过滤和增强企业制度相关的检索结果
"""
import logging
from typing import List, Dict
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import PolicyQueryInput, PolicyQueryOutput

logger = logging.getLogger(__name__)

# 制度相关的关键词
POLICY_KEYWORDS: List[str] = [
    "制度", "规定", "管理", "规范", "条例", "办法", "细则",
    "考勤", "薪酬", "福利", "奖惩", "绩效", "审批", "合规",
    "纪律", "行为", "守则", "准则", "政策"
]


def policy_query_node(
    state: PolicyQueryInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> PolicyQueryOutput:
    """
    title: 企业制度查询
    desc: 根据制度相关关键词过滤知识库检索结果，提取与企业制度、管理规定相关的内容
    """
    search_results: List[Dict] = state.search_results
    keywords: List[str] = state.keywords

    # 过滤制度相关的检索结果
    filtered: List[Dict] = []
    for item in search_results:
        content: str = item.get("content", "")
        score: float = float(item.get("score", 0.0))

        # 检查内容是否包含制度相关关键词
        is_policy_related: bool = any(
            kw in content for kw in POLICY_KEYWORDS
        )
        # 或者用户关键词在内容中出现
        has_user_keyword: bool = any(
            kw in content for kw in keywords
        ) if keywords else True

        if (is_policy_related or has_user_keyword) and score >= 0.3:
            filtered.append(item)

    # 如果没有过滤到结果，保留原始高分结果
    if not filtered and search_results:
        filtered = [
            item for item in search_results
            if float(item.get("score", 0.0)) >= 0.5
        ][:5]

    # 构建查询上下文
    context_parts: List[str] = []
    if keywords:
        context_parts.append(f"查询关键词: {', '.join(keywords)}")
    context_parts.append(f"匹配到 {len(filtered)} 条制度相关内容")

    query_context: str = "; ".join(context_parts)
    logger.info(f"企业制度查询完成，过滤出 {len(filtered)} 条结果")

    return PolicyQueryOutput(
        filtered_results=filtered,
        query_context=query_context
    )
