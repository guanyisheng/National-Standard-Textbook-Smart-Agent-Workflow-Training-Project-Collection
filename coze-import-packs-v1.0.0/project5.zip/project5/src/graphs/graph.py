# ⁠‌‌‌​​‌‌‌‌​‌​‌‌‌​‌​‌​​​​‌‌‌‌​​‌​​‌​‌‌‌​​‌‌​​‌‌​​‌‌‌‌​‌​​​‌​​​​​​‌‌​‌‌​​‌​​‌‌‌‌‌​​​​‌‌​​​‌​​‌‌​​‌‌​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​‌‌​​​‌‌​‌​​​​‌‌​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌‌‌‌​​‌‌‌​​‌​‌‌​​​‌​​​‌​‌‌​‌‌​‌‌‌​​‌​​‌​‌‌‌‌​‌‌​​‌‌‌​​‌‌‌​​‌​​‌​‌‌‌‌‌​‌​‌‌​‌​‌‌‌‌​​‌‌​‌​​‌‌‌​‌‌​​​​​‌‌‌‌‌​​‌​‌‌​‌‌‌‌‌‌‌​​​​‌​‌‌‌‌​​‌‌‌‌​‌​‌​​‌‌​‌‌​‌‌​⁠
"""
企业知识库增强RAG数智员工智能体 - 主图编排
"""
from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context

from graphs.state import (
    GlobalState,
    GraphInput,
    GraphOutput,
    SearchDecisionInput
)

# 导入节点函数
from graphs.nodes.intent_recognition_node import intent_recognition_node
from graphs.nodes.knowledge_search_node import knowledge_search_node
from graphs.nodes.policy_query_node import policy_query_node
from graphs.nodes.product_query_node import product_query_node
from graphs.nodes.process_query_node import process_query_node
from graphs.nodes.knowledge_fusion_node import knowledge_fusion_node
from graphs.nodes.review_node import review_node
from graphs.nodes.output_format_node import output_format_node


# ============================================================
# 条件分支路由函数
# ============================================================

def search_decision_path(state: SearchDecisionInput) -> str:
    """
    title: 智能检索决策
    desc: 根据意图识别结果决定进入哪个查询模块（企业制度/产品知识/业务流程）
    """
    category: str = state.intent_category
    if category == "产品知识":
        return "产品知识查询"
    elif category == "业务流程":
        return "业务流程查询"
    else:
        return "企业制度查询"


# ============================================================
# 构建主图
# ============================================================

builder = StateGraph(GlobalState, input_schema=GraphInput, output_schema=GraphOutput)

# 添加节点
builder.add_node(
    "intent_recognition",
    intent_recognition_node,
    metadata={"type": "agent", "llm_cfg": "config/intent_recognition_llm_cfg.json"}
)
builder.add_node("knowledge_search", knowledge_search_node)
builder.add_node("policy_query", policy_query_node)
builder.add_node("product_query", product_query_node)
builder.add_node("process_query", process_query_node)
builder.add_node(
    "knowledge_fusion",
    knowledge_fusion_node,
    metadata={"type": "agent", "llm_cfg": "config/knowledge_fusion_llm_cfg.json"}
)
builder.add_node(
    "review",
    review_node,
    metadata={"type": "agent", "llm_cfg": "config/review_llm_cfg.json"}
)
builder.add_node("output_format", output_format_node)

# 设置入口点
builder.set_entry_point("intent_recognition")

# 添加边：意图识别 → 知识库检索
builder.add_edge("intent_recognition", "knowledge_search")

# 添加条件分支：知识库检索 → 检索决策路由（根据意图分类选择查询模块）
builder.add_conditional_edges(
    source="knowledge_search",
    path=search_decision_path,
    path_map={
        "企业制度查询": "policy_query",
        "产品知识查询": "product_query",
        "业务流程查询": "process_query"
    }
)

# 添加边：三个查询分支 → 知识融合
builder.add_edge("policy_query", "knowledge_fusion")
builder.add_edge("product_query", "knowledge_fusion")
builder.add_edge("process_query", "knowledge_fusion")

# 添加边：知识融合 → 智能审核 → 输出格式化 → 结束
builder.add_edge("knowledge_fusion", "review")
builder.add_edge("review", "output_format")
builder.add_edge("output_format", END)

# 编译图
main_graph = builder.compile()
